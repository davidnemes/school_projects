/* 
 * Game Variables 
 */
const body = document.body
const r = document.querySelector(':root');


let tableSize = 0;
let playerName = "";
let activeSection = "menu";

let timer = null
let elapsedSeconds = 0;
let gameOver = false;

let alertDiv = document.querySelector("#alertDiv")
let playerNameInput = document.querySelector("#playerNameInput")
let gameTable = document.querySelector("#gameTable")
let table = []
let lastFieldSelected = { row: -1, column: -1 }

let toplistEasyContainer = document.querySelector("#toplistEasy")
let toplistHardContainer = document.querySelector("#toplistHard")
let toplistEasy = []
let toplistHard = []
let activeToplist = "easy" // "easy" or "hard"

/* 
 * Rendering
 */
let resizeTable = () => {
    // Set table width and height, calculate picWidth
    let x = 0
    if (innerWidth < 768) {
        gameTable.style.width = "inherit"
        gameTable.style.height = "inherit"
        x = gameTable.offsetWidth -1
    } else {
        let height = innerHeight - 2* (3* parseFloat(getComputedStyle(document.documentElement).fontSize))
        // let containerWidth = gameTable.parentElement.offsetWidth
        // x = height < containerWidth ? height : containerWidth
        x = height
        gameTable.style.width = x + "px"
        gameTable.style.height = x + "px"
    }
    
    // let picWidth = Math.floor((x - 10) / tableSize)
    let picWidth = (x - 10) / tableSize 
    picWidth = Math.floor(picWidth*10) / 10
    
    let fields = gameTable.children
    for (let i = 0; i < fields.length; i++) {
        fields[i].style.width = fields[i].style.height = picWidth + "px"
    }
    console.log("Table Resized!");
}
let renderTable = () => {
    let fields = gameTable.children
    for (let i = 0; i < fields.length; i++) {
        let row = Math.floor(i/tableSize)
        let column = i%tableSize
        let field = table[row][column]
        fields[i].src = `./pics/tiles/${field.src}.png`
        fields[i].style.transform = `rotate(${field.rotate}deg)`
    }
    if (lastFieldSelected.row == -1 && lastFieldSelected.column == -1) {
        document.querySelector(".gameField.selected")?.classList.remove("selected")
        r.style.setProperty('--gameFieldCursor', 'pointer');
    } else {
        document.querySelector(".gameField.selected")?.classList.remove("selected")
        document.querySelector(`.gameField[data-row="${lastFieldSelected.row}"][data-column="${lastFieldSelected.column}"]`).classList.add("selected")   
        r.style.setProperty('--gameFieldCursor', 'not-allowed');
    }
}
let renderToplist = () => {
    let listSample = `<li class="list-group-item d-flex justify-content-between align-items-start">
            <div class="ms-2 me-auto">
            <div class="fw-bold">#playerName#</div>
            Idő: #time#
            </div>
        </li>`

    toplistEasyContainer.innerHTML = ""
    toplistHardContainer.innerHTML = ""
    toplistEasy.slice(0, 10).forEach(result => {
        toplistEasyContainer.innerHTML += listSample.replace("#playerName#", result.playerName).replace("#time#", convertSeconds(result.elapsedSeconds))
    })
    toplistHard.slice(0, 10).forEach(result => {
        toplistHardContainer.innerHTML += listSample.replace("#playerName#", result.playerName).replace("#time#", convertSeconds(result.elapsedSeconds))
    })
}
let render = (only = null) => {
    // valid 'only' parameters = ["menu", "difficulty", "playerName", "timeElapsed", "resizeTable", "renderTable", "gameDetails", "toplist"] 
    
    if (only === null || only == "menu") {
        document.querySelector("section.active")?.classList.remove("active")
        document.querySelector(`section#${activeSection}`).classList.add("active")
    }
    
    switch (activeSection) {
        case "menu":
            
            // Set correct difficulty button active
            if (only === null || only == "difficulty") {
                document.querySelector(".setDifficulty.active")?.classList.remove("active")
                document.querySelector(`.setDifficulty[data-tablesize="${tableSize}"]`)?.classList.add("active")            
            }
            if (only === null || only == "playerName") document.querySelector("#playerNameInput").value = playerName
            break;
        case "game":
            if (only === null || only == "playerName") document.querySelector("#playerName").innerHTML = playerName
            if (only === null || only == "timeElapsed") document.querySelector("#timeElapsed").innerHTML = convertSeconds(elapsedSeconds)
            if (only === null || only == "resizeTable") resizeTable()
            if (only === null || only == "renderTable") renderTable()
            if (only === null || only == "gameDetails") {
                // document.querySelector(".gameDetailsDiv.active")?.classList.remove("active")
                if (!gameOver) document.querySelector("#gameDetails.gameOver")?.classList.remove("gameOver")
                    else document.querySelector("#gameDetails").classList.add("gameOver")
            }
            if (only === null || only == "toplist") {
                renderToplist()
                document.querySelector(".toplistLink.active")?.classList.remove("active")
                document.querySelector(`.toplistLink[data-toplist="${activeToplist}"]`)?.classList.add("active")
                document.querySelector(".toplist.active")?.classList.remove("active")
                document.querySelector(`.toplist[data-toplist="${activeToplist}"]`)?.classList.add("active")
            }
            break;
        default:
            break;
    }
}



/* 
 * Game functions
 */

function initGame() {
    // Clearing Last game
    table = []
    gameTable.innerHTML = ""
    gameOver = false

    // Setting name
    playerName = playerNameInput.value
    // Starting timer
    timer = setInterval(secondElapsed, 1000)

    // Selecting and creating table
    let tableChoice = tables[tableSize][randInt(0, tables[tableSize].length)]
    // let tableChoice = tables[tableSize][0]
    for (let i = 0; i < tableSize; i++) {
        let newRow = []
        for (let j = 0; j < tableSize; j++) {
            let newField = {}

            let splitted = tableChoice[i][j].split(":")
            let src = splitted[0]
            let rotate = splitted.length > 1 ? parseInt(splitted[1]) : 0
            let outputs = {}
            switch(src) {
                case "empty":
                    outputs.up = outputs.down = outputs.left = outputs.right = false
                    break
                case "mountain":
                    if ([180, 270].includes(rotate)) outputs.up = false
                    if ([0, 90].includes(rotate)) outputs.down = false
                    if ([90, 180].includes(rotate)) outputs.left = false
                    if ([270, 0].includes(rotate)) outputs.right = false
                    break
                case "bridge":
                    if (rotate == 0) outputs.up = outputs.down = false
                    else if (rotate == 90) outputs.left = outputs.right = false
                    break
                case "oasis":
                    break
                default:
                    console.log("Error in table construction: field type not found!");
            }

            newField.outputs = outputs
            newField.connectingOutputs = []
            newField.src = src
            newField.rotate = rotate

            newRow.push(newField)
        }
        table.push(newRow)
    }

    // Fill gameTable
    // gameTable.children.
    for (let i = 0; i < tableSize; i++) {
        for (let j = 0; j < tableSize; j++) {
            newNode("img", gameTable, img => {
                img.setAttribute('draggable', false)
                img.classList.add("gameField")
                img.dataset.row = i
                img.dataset.column = j
            })
        }
    }
}
function validatePlayerData() {
    // Validation
    playerName = playerNameInput.value
    if (playerName == "" || tableSize == 0) {
        alertDiv.classList.add("active")
        return false;
    } else {
        alertDiv.classList.remove("active")
        return true;
    }
}
function computeTableFields() {
    // compute fields src and rotate
    for (let i = 0; i < tableSize; i++) {
        for (let j = 0; j < tableSize; j++) {
            computeTableField(i, j)
        }
    }
}
function computeTableField(row, column) {
    if (row === null || column === null) return

    let field = table[row][column]
    if (Object.keys(field.outputs).length > 2) {
        // console.log(field.outputs);
        
        if ((field.outputs.up && field.outputs.down) || (field.outputs.right && field.outputs.left)) {
            field.src = "straight_rail"
            if (field.outputs.up && field.outputs.down) field.rotate = 0
            else field.rotate = 90
        } else if (Object.values(field.outputs).filter(val => val).length == 2) {
            field.src = "curve_rail"
            if (field.outputs.right && field.outputs.down) field.rotate = 0
            else if (field.outputs.left && field.outputs.down) field.rotate = 90
            else if (field.outputs.left && field.outputs.up) field.rotate = 180
            else if (field.outputs.right && field.outputs.up) field.rotate = 270
        } else {
            field.src = "empty"
        }
    } else if(Object.keys(field.outputs).length == 2) {
        if (Object.values(field.outputs).every(val => val)) {
            if (!field.src.includes("_rail")) field.src += "_rail"
        } else {
            field.src = field.src.split("_")[0]
        }
    }
}
function corrigateLastMove() {
    let lf = lastFieldSelected
    if (lf.column == -1 || lf.row == -1) return // railing has not started yet
    
    // Corrigate last move, if can
    let lastField = table[lf.row][lf.column]
    let activeOutputs = Object.keys(lastField.outputs).filter(dir => lastField.outputs[dir]).filter(dir => !lastField.connectingOutputs.includes(dir))
    // console.log(activeOutputs);
    
    if (activeOutputs.length == 1) {
        let targetRow = lf.row
        let targetColumn = lf.column
        if (activeOutputs[0] == "up") targetRow--
        else if (activeOutputs[0] == "down") targetRow++
        else if (activeOutputs[0] == "right") targetColumn++
        else if (activeOutputs[0] == "left") targetColumn--
        
        if (targetRow >= 0 && targetRow < tableSize && targetColumn >= 0 && targetColumn < tableSize) {
            let neededOutput = inverseDirection(activeOutputs[0])
            if (neededOutput in table[targetRow][targetColumn].outputs &&
                table[targetRow][targetColumn].outputs[neededOutput]){
                table[lf.row][lf.column].outputs[activeOutputs[0]] = true
                table[lf.row][lf.column].connectingOutputs.push(activeOutputs[0])
                table[targetRow][targetColumn].outputs[neededOutput] = true
                table[targetRow][targetColumn].connectingOutputs.push(neededOutput)

            }
        }
    }
}
function loadToplists() {
    let storedToplistEasy = JSON.parse(localStorage.getItem("toplistEasy"))
    let storedToplistHard = JSON.parse(localStorage.getItem("toplistHard"))
    if (storedToplistEasy) toplistEasy = storedToplistEasy
    if (storedToplistHard) toplistHard = storedToplistHard
}
function insertToplistResult(level, result) {
    let arr = level == "easy" ? toplistEasy : level == "hard" ? toplistHard : null
    if (arr === null) return
    
    let index = 0
    while (index < arr.length && arr[index].elapsedSeconds <= result.elapsedSeconds) index++    

    arr.splice(index, 0, result)
    
    // Saving Toplist to Localestorage
    let localStorageName = level == "easy" ? "toplistEasy" : level == "hard" ? "toplistHard" : null
    if (localStorageName !== null) localStorage.setItem(localStorageName, JSON.stringify(arr));
}

/* 
 * Event handlers
 */

let secondElapsed = () => {
    elapsedSeconds++
    render("timeElapsed")
}
let navigationButtonClicked = (event, element) => {
    let nextSection = element.dataset.navigateto
    if (nextSection == "game") {
        if (!validatePlayerData()) return;
        initGame()
    }
    activeSection = nextSection

    render()
}
let closeMenuAlert = (event, element) => {
    alertDiv.classList.remove("active")
}
let setDifficultyClicked = (event, element) => {
    tableSize = parseInt(element.dataset.tablesize)
    // console.log(tableSize);
    render("difficulty") 
}

let startRailing = (event, element) => {
    let row = element.dataset.row
    let column = element.dataset.column
    let ou = table[row][column].outputs
    // console.log(row);
    // console.log(column);
    
    if (Object.keys(ou).length == 0) return
    
    switch(Object.keys(ou).length) {
        case 2:
            Object.keys(ou).forEach(direction => ou[direction] = true) // mountain or bridge
            break
        case 4:
            ou.up = ou.down = true
    }

    lastFieldSelected.column = column
    lastFieldSelected.row = row
    
    computeTableField(row, column)
    render("renderTable")
}

let continueRailing = (event, element) => {
    let lf = lastFieldSelected
    if (lf.column == -1 || lf.row == -1) return // railing has not started yet

    // return if filled or oasis
    let row = element.dataset.row
    let column = element.dataset.column
    let field = table[row][column]
    let lastField = table[lf.row][lf.column]

    if (lf.row == row && lf.column == column) return // self
    if (Object.keys(field.outputs) == 0) return // oasis

    // Return if lastselected is not neighbour
    if (Math.abs(lf.row - row) > 1) return
    if (Math.abs(lf.column - column) > 1) return
    if (Math.abs(lf.row - row) == 1 && Math.abs(lf.column - column) == 1) return

    // Specify direction
    let movedTo = ""
    if (row - lf.row == -1 && column - lf.column == 0) movedTo = "up"
    else if (row - lf.row == 1 && column - lf.column == 0) movedTo = "down"
    else if (row - lf.row == 0 && column - lf.column == -1) movedTo = "left"
    else if (row - lf.row == 0 && column - lf.column == 1) movedTo = "right"
    // console.log(movedTo);
    let movedFrom = inverseDirection(movedTo)
    
    if (!(movedTo in lastField.outputs)) return // can't go that way
    if (!(movedFrom in field.outputs)) return // doesn't have that needed output
    if (field.connectingOutputs.length == 2) return // already has two connectingOutputs
    if (lastField.connectingOutputs.length == 2) return // lastField already has two connectingOutputs

    // Setting Field outputs
    if (Object.keys(field.outputs).length == 2) {
        Object.keys(field.outputs).forEach(dir => field.outputs[dir] = true)
    } else {
        Object.keys(field.outputs).forEach(dir => field.outputs[dir] = false)
        field.outputs[movedFrom] = true
        if (field.connectingOutputs.length > 0) field.outputs[field.connectingOutputs[0]] = true
        else field.outputs[movedTo] = true
    }
    field.connectingOutputs.push(movedFrom)

    // Setting Lastselected outputs
    let activeOutputs = Object.keys(lastField.outputs).filter(dir => lastField.outputs[dir]).filter(dir => !lastField.connectingOutputs.includes(dir))
    if (!activeOutputs.includes(movedTo)) {
        lastField.outputs[movedTo] = true
        lastField.outputs[activeOutputs[0]] = false // activeOutputs must not be empty
    }
    lastField.connectingOutputs.push(movedTo)
    // console.log(lastField.outputs);
    // console.log(activeOutputs);
    // console.log("continue railing");
    
    
    computeTableField(lf.row, lf.column)
    computeTableField(row, column)

    // Setting Lastselected
    lastFieldSelected.row = row
    lastFieldSelected.column = column

    render("renderTable")
}
let endRailing = (event, element) => {
    let lf = lastFieldSelected
    if (lf.column == -1 || lf.row == -1) return

    // Corrigating last move, if player did not finish the track by one
    corrigateLastMove()

    // Check if game won
    let gameWon = true
    for (let i = 0; i < tableSize; i++) {
        for (let j = 0; j < tableSize; j++) {
            
            if (Object.keys(table[i][j].outputs).length == 0) continue
            if (table[i][j].connectingOutputs.length != 2) gameWon = false

            if (!gameWon) break
        }
        if (!gameWon) break
    }

    if (gameWon) {
        // Game Over
        gameOver = true
        clearInterval(timer)

        // Saving result
        let result = { playerName, elapsedSeconds }
        if (tableSize == 5) {
            activeToplist = "easy"
            insertToplistResult("easy", result)
        } else if (tableSize == 7)  {
            activeToplist = "hard"
            insertToplistResult("hard", result)
        }
        
        lf.column = lf.row = -1
        render()
    } else {        
        lf.column = lf.row = -1

        for (let i = 0; i < tableSize; i++) {
            for (let j = 0; j < tableSize; j++) {
                let ou = table[i][j].outputs
                Object.keys(ou).forEach(direction => ou[direction] = false)
                table[i][j].connectingOutputs = []
            }   
        }

        // console.log("end railing");
        computeTableFields()
        render("renderTable")
    }
    
}
let switchToplist = (event, element) => {
    activeToplist = element.dataset.toplist
    render("toplist")
}


delegate(body, ".setDifficulty", "click", setDifficultyClicked)
delegate(body, ".navigation", "click", navigationButtonClicked)
delegate(body, "#alertDiv .btn-close", "click", closeMenuAlert)
delegate(gameTable, ".gameField", "mousedown", startRailing)
delegate(gameTable, ".gameField", "mouseover", continueRailing)
delegate(body, "body", "mouseup", endRailing)
delegate(body, ".toplistLink", "click", switchToplist)

addEventListener("resize", resizeTable)

// Initialize page
loadToplists()
render()


/*
 * Helper Functions
 */
function newNode (type, parent, insertContent) {
    let node = document.createElement(type)
    insertContent(node)
    parent.appendChild(node)
}

function delegate(parent, child, when, what){
    function eventHandlerFunction(event){
        let eventTarget  = event.target;
        let eventHandler = this;
        let closestChild = eventTarget.closest(child);

        if(eventHandler.contains(closestChild)){
            what(event, closestChild);
        }
    }

    parent.addEventListener(when, eventHandlerFunction);
}

function convertSeconds(seconds) {
    let minutes = Math.floor(seconds / 60);
    let extraSeconds = seconds % 60;
    minutes = minutes < 10 ? "0" + minutes : minutes;
    extraSeconds = extraSeconds< 10 ? "0" + extraSeconds : extraSeconds;
    return minutes + " : " + extraSeconds;
}

function inverseDirection(dir) {
    let directions = ["up", "left", "down", "right"]
    return directions[(directions.indexOf(dir)+directions.length/2) % directions.length]
}

function randInt(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}


