<?php
require_once("../lib/_init.php");

if (!$user || !$user["admin"]) redirect("/");

$errors = get_flash_data("errors");
$data = get_flash_data("data");


?>

<?php page_start("iKarRental - Új Autó felvitele"); ?>
<?php page_header(isset($user)); ?>

<main class="container form">
    <h1 class="text-center mt-5">Új Autó felvitele</h1>
    <form action="/actions/create.php" method="POST" class="mt-4" novalidate>
    <div class="mb-3">
            <label for="brand" class="form-label">Márka</label>
            <input type="text" class="form-control" name="brand" id="brand" placeholder="Márka" value="<?= $data ? $data["brand"] : null ?>">
            <?php if($errors && isset($errors["brand"])) : ?>
                <div class="form-text alert alert-danger"><b><?= $errors["brand"] ?></b></div>
            <?php endif ?>
        </div>
        <div class="mb-3">
            <label for="model" class="form-label">Típus</label>
            <input type="text" class="form-control" name="model" id="model" placeholder="Típus" value="<?= $data ? $data["model"] : null ?>">
            <?php if($errors && isset($errors["model"])) : ?>
                <div class="form-text alert alert-danger"><b><?= $errors["model"] ?></b></div>
            <?php endif ?>
        </div>
        <div class="mb-3">
            <label for="year" class="form-label">Évjárat</label>
            <input type="number" class="form-control" name="year" id="year" value="<?= $data ? $data["year"] : null ?>">
            <?php if($errors && isset($errors["year"])) : ?>
                <div class="form-text alert alert-danger"><b><?= $errors["year"] ?></b></div>
            <?php endif ?>
        </div>
        <div class="mb-3">
            <label for="transmission" class="form-label">Váltó típusa</label>
            <select class="form-select" name="transmission">
                <option <?= $data && $data["transmission"] == "" ? "selected" : "" ?> value="">Váltó típusa</option>
                <option <?= $data && $data["transmission"] == "Manual" ? "selected" : "" ?> value="Manual">Manuális</option>
                <option <?= $data && $data["transmission"] == "Automatic" ? "selected" : "" ?> value="Automatic">Automata</option>
            </select>
            <?php if($errors && isset($errors["transmission"])) : ?>
                <div class="form-text alert alert-danger"><b><?= $errors["transmission"] ?></b></div>
            <?php endif ?>
        </div>
        <div class="mb-3">
            <label for="fuel_type" class="form-label">Üzemanyag típusa</label>
            <select class="form-select" name="fuel_type">
                <option <?= $data && $data["fuel_type"] == "" ? "selected" : "" ?> value="">Üzemanyag típusa</option>
                <option <?= $data && $data["fuel_type"] == "Petrol" ? "selected" : "" ?> value="Petrol">Benzin</option>
                <option <?= $data && $data["fuel_type"] == "Diesel" ? "selected" : "" ?> value="Diesel">Dízel</option>
                <option <?= $data && $data["fuel_type"] == "Electric" ? "selected" : "" ?> value="Electric">Elektromos</option>
            </select>
            <?php if($errors && isset($errors["fuel_type"])) : ?>
                <div class="form-text alert alert-danger"><b><?= $errors["fuel_type"] ?></b></div>
            <?php endif ?>
        </div>
        <div class="mb-3">
            <label for="passengers" class="form-label">Maximális utasszám</label>
            <input type="number" class="form-control" name="passengers" id="passengers" value="<?= $data ? $data["passengers"] : null ?>">
            <?php if($errors && isset($errors["passengers"])) : ?>
                <div class="form-text alert alert-danger"><b><?= $errors["passengers"] ?></b></div>
            <?php endif ?>
        </div>
        <div class="mb-3">
            <label for="daily_price_huf" class="form-label">Napidíj Ft-ban</label>
            <input type="number" class="form-control" name="daily_price_huf" id="daily_price_huf" value="<?= $data ? $data["daily_price_huf"] : null ?>">
            <?php if($errors && isset($errors["daily_price_huf"])) : ?>
                <div class="form-text alert alert-danger"><b><?= $errors["daily_price_huf"] ?></b></div>
            <?php endif ?>
        </div>
        <div class="mb-3">
            <label for="image" class="form-label">Kép URL-je</label>
            <input type="text" class="form-control" name="image" id="image" placeholder="URL" value="<?= $data ? $data["image"] : null ?>">
            <?php if($errors && isset($errors["image"])) : ?>
                <div class="form-text alert alert-danger"><b><?= $errors["image"] ?></b></div>
            <?php endif ?>
        </div>
        <button type="submit" class="btn btn-warning fw-bold mb-3">Mentés</button>
    </form>
</main>

<?php page_end() ?>

