<?php function page_header($logged_in) { ?>

<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="/">iKarRental</a>

    <div class="pull-right">
        <?php if (!$logged_in) : ?>
            <a href="/pages/login.php" class="btn btn-dark">Bejelentkezés</a>
            <a href="/pages/registration.php" class="btn btn-warning">Regisztráció</a>
        <?php else : ?>
            <a href="/pages/profile.php">
                <img id="navProfileImg" src="/imgs/profile_image.jpg" alt="img">
            </a>
        <?php endif ?>
    </div>
  </div>
</nav>

<?php } ?>
