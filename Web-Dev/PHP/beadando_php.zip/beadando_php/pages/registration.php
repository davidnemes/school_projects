<?php
require_once("../lib/_init.php");

$errors = get_flash_data("errors");
$data = get_flash_data("data");

?>

<?php page_start("iKarRental - Regisztráció"); ?>
<?php page_header(isset($user)); ?>

<main class="container form">
    <h1 class="text-center mt-5">Regisztráció</h1>
    <form action="/actions/registration.php" method="POST" class="mt-4" novalidate>
    <div class="mb-3">
            <label for="full_name" class="form-label">Teljes név</label>
            <input type="text" class="form-control" name="full_name" id="full_name" placeholder="Teljes Név" value="<?= $data ? $data["full_name"] : null ?>">
            <?php if($errors && isset($errors["full_name"])) : ?>
                <div class="form-text alert alert-danger"><b><?= $errors["full_name"] ?></b></div>
            <?php endif ?>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Email cím</label>
            <input type="email" class="form-control" name="email" id="email" placeholder="pelda@cim.hu" value="<?= $data ? $data["email"] : null ?>">
            <?php if($errors && isset($errors["email"])) : ?>
                <div class="form-text alert alert-danger"><b><?= $errors["email"] ?></b></div>
            <?php endif ?>
        </div>
        <div class="mb-3">
            <label for="password" class="form-label">Jelszó</label>
            <input type="password" class="form-control" name="password" id="password" placeholder="***">
            <?php if($errors && isset($errors["password"])) : ?>
                <div class="form-text alert alert-danger"><b><?= $errors["password"] ?></b></div>
            <?php endif ?>
        </div>
        <div class="mb-3">
            <label for="password_confirm" class="form-label">Jelszó még egyszer</label>
            <input type="password" class="form-control" name="password_confirm" id="password_confirm" placeholder="***">
            <?php if($errors && isset($errors["password_confirm"])) : ?>
                <div class="form-text alert alert-danger"><b><?= $errors["password_confirm"] ?></b></div>
            <?php endif ?>
        </div>
        <button type="submit" class="btn btn-warning fw-bold">Regisztráció</button>
    </form>
</main>

<?php page_end() ?>

