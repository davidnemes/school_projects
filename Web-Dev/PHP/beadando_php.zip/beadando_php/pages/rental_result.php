<?php
require_once("../lib/_init.php");

$data = get_flash_data("data");
if (!$data) redirect("/");

$car = $Car->findById($data["car_id"]);

?>

<?php page_start("iKarRental - Foglalás eredménye"); ?>
<?php page_header(isset($user)); ?>

<main class="container form ">
    <div class="text-center pt-2 pt-lg-5">
        <?php if ($data["result"] == "success") : ?>
            <img src="/imgs/success.png" alt="tick" class="w-50 w-lg-25 mx-auto">
            <h1 class="text-center mt-2">Sikeres foglalás</h1>
            <p>
                A(z) <b><?= $car["brand"]." ".$car["model"] ?></b> sikeresen lefoglalva 
                <?= (new DateTime($data["date_from"]))->format("Y.m.d.") . "-" . (new DateTime($data["date_to"]))->format("Y.m.d.") ?> intervallumra. <br>
                Foglalásod státuszát a profiloldalon követheted nyomon.
            </p>
            <a class="btn btn-warning" href="/pages/profile.php">Profilom</a>
        <?php elseif ($data["result"] == "fail") : ?>
            
            <img src="/imgs/fail.png" alt="x" class="w-50 w-lg-25 mx-auto">
            <h1 class="text-center mt-2">Sikertelen foglalás</h1>
            <p>
                A(z) <b><?= $car["brand"]." ".$car["model"] ?></b> nem elérhető a megadott
                <?= (new DateTime($data["date_from"]))->format("Y.m.d.") . "-" . (new DateTime($data["date_to"]))->format("Y.m.d.") ?> intervallumban. <br>
                Próbálj megadni egy másik intervallumot, vagy keress egy másik járművet.
            </p>
            <a class="btn btn-warning" href="/pages/car_details.php?id=<?= $data["car_id"] ?>">Vissza a jármű oldalára</a>
        <?php endif ?>
    </div>
</main>

<?php page_end() ?>

