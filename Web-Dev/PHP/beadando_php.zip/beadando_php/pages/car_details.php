<?php
require_once("../lib/_init.php");

$carId = $_GET["id"] ?? null;
if ($carId === null) redirect("/");

$car = $Car->findById($carId);

$errors = get_flash_data("errors");
$data = get_flash_data("data");

?>

<?php page_start("iKarRental"); ?>
<?php page_header(isset($user)); ?>


<main class="container mt-5">
    <?php if(isset($car)) : ?>
        <div class="car-card d-flex flex-column flex-lg-row align-items-center p-3">
            <!-- Autó képe -->
            <div class="col-12 col-lg-6 mb-3 mb-lg-0 me-lg-3">
                <img src="<?= $car["image"] ?>" alt="<?= $car["brand"]." ".$car["model"] ?>">
            </div>
            <!-- Adatok és információk -->
            <div class="col-12 col-lg-6">
                <div class="car-details py-3">
                    
                    <div class="d-flex flex-wrap justify-content-between align-items-center">
                        <h2 class="me-1 mb-0"><?= $car["brand"] ?> <span class="fw-bold"><?= $car["model"] ?></span></h2>
                        <div class="fw-bold fs-2"><?= number_format($car["daily_price_huf"], 0, ",", ".") ?> Ft<span class="ms-1 mb-1 fs-6 text-muted fw-normal">/nap</span></div>
                    </div>
                    <div>
                        <small>Üzemanyag:</small> <?= ucfirst(fuelTypeToHun($car["fuel_type"])) ?> <br>
                        <small>Váltó:</small> <?= ucfirst(transmissionToHun($car["transmission"])) ?><br>
                        <small>Gyártási év:</small> <?= $car["year"] ?> <br>
                        <small>Férőhelyek száma:</small> <?= $car["passengers"] ?>
                    </div>
                    <form action="/actions/rental.php?id=<?= $carId ?>" method="POST" novalidate>
                        <div class="d-flex gap-3 mt-2">
                            <?php if(isset($user)) : ?>
                                <button class="btn btn-primary fw-bold" type="button" data-bs-toggle="collapse" data-bs-target="#selectInterval" aria-expanded="<?= $errors ? "true" :  "false"?>" aria-controls="selectInterval">
                                    Dátum kiválasztása
                                </button>
                            <?php else : ?>
                                <a class="btn btn-warning fw-bold" href="/pages/login.php">Lefoglalom</a>
                            <?php endif ?>
                        </div>
                        <div class="collapse mt-3 <?= $errors ? "show" : "" ?>" id="selectInterval">
                            <div class="d-flex align-items-center mb-2">
                                <span class="text-white mx-2">Ettől:</span>
                                <input type="date" class="form-control text-center" name="date_from" value="<?= $data ? $data["date_from"] : "" ?>">
                                <span class="text-white mx-2">Eddig:</span>
                                <input type="date" class="form-control text-center" name="date_to" value="<?= $data ? $data["date_to"] : "" ?>">
                            </div>
                            <button class="btn btn-warning fw-bold" type="submit">Lefoglalom</button>
                            <?php if($errors) : 
                                    foreach($errors as $error_type => $error) :?>
                                    <div class="form-text alert alert-danger"><b><?= $error ?></b></div>
                            <?php endforeach;
                                endif ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php else : ?>
        <h1 class="text-center">A keresett autó nem található!</h1>
    <?php endif ?>
</main>


<?php page_end() ?>
