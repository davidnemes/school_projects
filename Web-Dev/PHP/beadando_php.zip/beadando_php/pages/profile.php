<?php
require_once("../lib/_init.php");

if (!isset($user)) redirect("/");

$rentals = $Rental->findAll(["user_id" => $user["id"]]);
foreach ($rentals as $idx => $rental) {
    $rentals[$idx]["car"] = $Car->findById($rental["car_id"]);
}
?>

<?php page_start("iKarRental - Profilom"); ?>
<?php page_header(isset($user)); ?>

<main class="container">
    <div id="profileDataDiv" class="d-flex flex-wrap align-items-start justify-content-between p-2 p-lg-5">
        <div class="d-flex align-items-center justify-content-start">
            <img src="/imgs/profile_image.jpg" alt="Profile image" class="rounded-3 me-3">
            <p>
                Bejelentkezve, mint <br>
                <span class="fs-2 fw-bold"><?= $user["full_name"] ?></span>
            </p>
        </div>
        <a class="btn btn-warning fw-bold float-end mt-3" href="/actions/logout.php">Kijelentkezés</a>
    </div>
    <h2>Foglalásaim</h2>
    <!-- Lefoglalt Autók -->
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 mb-2">
        <?php foreach($rentals as $rental) : ?>
            <div class="col">
                <div class="car-card">
                    <img src="<?= $rental["car"]["image"] ?>" alt="<?= $rental["car"]["brand"]." ".$rental["car"]["model"] ?>">
                    <div class="car-details p-2">
                        <h2 class="fw-bold"><?= (new DateTime($rental["date_from"]))->format("m.d.") ?> - <?= (new DateTime($rental["date_to"]))->format("m.d.") ?></h2>
                        <h5><?= $rental["car"]["brand"]?> <span class="fw-bold"><?= $rental["car"]["model"] ?></span></h5>
                        <p><?= $rental["car"]["passengers"] ?> férőhely - <?= transmissionToHun($rental["car"]["transmission"]) ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach ?>
    </div>
</main>

<?php page_end() ?>

