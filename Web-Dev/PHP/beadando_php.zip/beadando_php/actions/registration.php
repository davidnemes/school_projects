<?php
require_once("../lib/_init.php");

$data = [
    "full_name" => $_POST["full_name"] ?? null,
    "email" => $_POST["email"] ?? null,
    "password" => $_POST["password"] ?? null,
    "password_confirm" => $_POST["password_confirm"] ?? null,
];

$errors = [];
$user = null;

if (!$data["full_name"]) $errors["full_name"] = "Teljes név megadása kötelező!";

if (!$data["email"]) $errors["email"] = "Email megadása kötelező!";
else if (!filter_var($data["email"], FILTER_VALIDATE_EMAIL)) $errors["email"] = "Helytelen email cím!";
else {
    $user = $User->findOne(["email" => $data["email"]]);
    if ($user) $errors["email"] = "Foglalt email cím!";
}

if (!$data["password"]) $errors["password"] = "Jelszó megadása kötelező!";
else if (strlen($data["password"]) < 8) $errors["password"] = "Jelszó hossza minimum 8 karakter!";

if ($data["password"] != $data["password_confirm"]) $errors["password_confirm"] = "A két jelszó nem egyezik!";


if (count($errors) == 0) {
    unset($data["password_confirm"]);
    $data["admin"] = false;
    $data["password"] = password_hash($data["password"], PASSWORD_DEFAULT);
    $userId = $User->add($data);

    set_session_data("user", $User->findById($userId));
    redirect("/");
} else {
    set_flash_data("errors", $errors);
    set_flash_data("data", $data);
    redirect("/pages/registration.php");
}
