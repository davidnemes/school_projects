<?php
require_once("../lib/_init.php");

if ($user && $user["admin"]) {
    $id = $_GET["id"] ?? null;

    if ($id) {
        
        $Car->delete($id);
        $rentals = $Rental->findAll(["car_id" => $id]);
        foreach ($rentals as $rental) {
            $Rental->delete($rental["id"]);
        }
    }
}

redirect("/");

