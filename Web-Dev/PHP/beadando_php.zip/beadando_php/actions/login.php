<?php
require_once("../lib/_init.php");

$data = [
    "email" => $_POST["email"] ?? null,
    "password" => $_POST["password"] ?? null,
];

$errors = [];
$user = null;
if ($data["email"] == null || strlen($data["email"]) == 0) {
    $errors["email"] = "Töltsd ki az email címet!";
} else if (!filter_var($data["email"], FILTER_VALIDATE_EMAIL)) {
    $errors["email"] = "Helytelen email cím!";
} else {
    $user = $User->findOne(["email" => $data["email"]]);
    if ($user == null || !password_verify($data['password'], $user['password'])) {
        $errors["password"] = "Sikertelen Bejelentkezés!";
    }
}

if (count($errors) == 0) {
    set_session_data("user", $user);
    redirect("/");
} else {
    set_flash_data("errors", $errors);
    set_flash_data("data", $data);
    redirect("/pages/login.php");
}

