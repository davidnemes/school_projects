<?php
require_once("../lib/_init.php");

if ($user && $user["admin"]) {
    $id = $_GET["id"] ?? null;

    if ($id) {
        $Rental->delete($id);
    }
}

redirect("/");