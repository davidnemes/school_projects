<?php

require_once("../lib/_init.php");

session_destroy();

redirect("/");
