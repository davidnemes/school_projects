<?php
require_once("../lib/_init.php");

$id = $_GET["id"] ?? null;
$car = $Car->findById($id);
if (!$user || !$user["admin"] || !$car) redirect("/");


$data = [
    "id" => intval($id),
    "brand" => $_POST["brand"] ?? null,
    "model" => $_POST["model"] ?? null,
    "year" => isset($_POST["year"]) && $_POST["year"] ? intval($_POST["year"]) : null,
    "transmission" => $_POST["transmission"] ?? null,
    "fuel_type" => $_POST["fuel_type"] ?? null,
    "passengers" => isset($_POST["passengers"]) && $_POST["passengers"] ? intval($_POST["passengers"]) : null,
    "daily_price_huf" => isset($_POST["daily_price_huf"]) && $_POST["daily_price_huf"] ? intval($_POST["daily_price_huf"]) : null,
    "image" => $_POST["image"] ?? null,
];

// var_dump($data);
// exit;

$errors = [];

if (!$data["brand"]) $errors["brand"] = "Márka kitöltése kötelező!";
if (!$data["model"]) $errors["model"] = "Típus kitöltése kötelező!";
if (!$data["year"]) $errors["year"] = "Évjárat kitöltése kötelező!";
else if ($data["year"] <= 0 ) $errors["year"] = "Évjárat pozitív egész legyen!";
if (!$data["transmission"]) $errors["transmission"] = "Váltó típusának megadása kötelező!";
if (!$data["fuel_type"]) $errors["fuel_type"] = "Üzemanyag típusának megadása kötelező!";

if (!$data["passengers"]) $errors["passengers"] = "Maximális utasszám kitöltése kötelező!";
else if ($data["passengers"] <= 0 ) $errors["passengers"] = "Maximális utasszám pozitív egész legyen!";
if (!$data["daily_price_huf"]) $errors["daily_price_huf"] = "Napidíj Ft-ban kitöltése kötelező!";
else if ($data["daily_price_huf"] <= 0 ) $errors["daily_price_huf"] = "Napidíj Ft-ban pozitív egész legyen!";

if (!$data["image"]) $errors["image"] = "Kép URL-je kitöltése kötelező!";

if (count($errors) == 0) {
    $Car->update($id, $data);
    redirect("/");
} else {
    set_flash_data("errors", $errors);
    set_flash_data("data", $data);
    redirect("/pages/edit.php?id=".$id);
}
