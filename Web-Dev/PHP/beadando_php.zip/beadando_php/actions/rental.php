<?php

require_once("../lib/_init.php");

if (!isset($user)) {
    redirect("/pages/login.php");
}

$data = [
    "car_id" => $_GET["id"] ?? null,
    "user_id" => $user["id"] ?? null,
    "date_from" => $_POST["date_from"] ?? null,
    "date_to" => $_POST["date_to"] ?? null,
];

$car = $Car->findById($data["car_id"]);
$errors = [];
if (!isset($car)) $errors["car"] = "Az autó nem található!";
if (!$data["date_from"] || !$data["date_from"]) $errors["date"] = "Dátum megadása kötelező!";
else if ((new DateTime($data["date_from"])) < (new DateTime())) $errors["date"] = "Csak jövőbeni dátumot lehet kiválasztani!";
else if ((new DateTime($data["date_from"])) > (new DateTime($data["date_to"]))) $errors["date"] = "Helytelen dátum érték!";

if (count($errors) == 0) {
    $rentals = $Rental->findAll(["car_id" => $data["car_id"]]);
    $rentalConflict = false;
    foreach ($rentals as $rental) {
        if (isRentalConflict($rental, $data)) {
            $rentalConflict = true;
            break;
        }
    }

    if (!$rentalConflict) $Rental->add($data);
    $data["result"] = $rentalConflict ? "fail" : "success";
    set_flash_data("data", $data);
    
    redirect("/pages/rental_result.php");
} else {
    set_flash_data("errors", $errors);
    set_flash_data("data", $data);
    redirect("/pages/car_details.php?id=".$data["car_id"]);
}
