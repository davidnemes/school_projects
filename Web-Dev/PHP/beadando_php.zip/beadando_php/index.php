<?php
require_once("lib/_init.php");

$cars = $Car->findAll();

// Szűrések
$filters = [
    "passengers" => $_GET["passengers"] ?? null,
    "date_from" => $_GET["date_from"] ?? null,
    "date_to" => $_GET["date_to"] ?? null,
    "transmission" => $_GET["transmission"] ?? null,
    "price_from" => isset($_GET["price_from"]) && $_GET["price_from"] ? intval($_GET["price_from"]) : null,
    "price_to" => isset($_GET["price_to"]) && $_GET["price_to"] ? intval($_GET["price_to"]) : null,
];

$filtered = [];
foreach ($cars as $id => $car) {
    $good = true;
    if ($filters["passengers"] && $car["passengers"] < $filters["passengers"]) $good = false;
    if ($filters["transmission"] != "" && $car["transmission"] != $filters["transmission"]) $good = false;
    if ($filters["price_from"] && $car["daily_price_huf"] < $filters["price_from"]) $good = false;
    if ($filters["price_to"] && $car["daily_price_huf"] > $filters["price_to"]) $good = false;
    if ($filters["date_from"] && $filters["date_to"]) {
        $rentals = $Rental->findAll(["car_id" => strval($id)]);
        foreach ($rentals as $rental) {
            if (isRentalConflict($rental, $filters)) $good = false;
        }
    }

    if ($good) $filtered[$id] = $car; 
}
$cars = $filtered;

?>

<?php page_start("iKarRental"); ?>
<?php page_header(isset($user)); ?>

<main class="container">
    <div class="header text-start pt-5 pb-2">
        <h1 class="fw-bold">Kölcsönözz autókat könnyedén!</h1>
        <?php if(!isset($user)) : ?>
            <a href="/pages/registration.php" class="btn btn-warning fw-bold">Regisztráció</a>
        <?php elseif ($user["admin"]) : ?>
            <a href="/pages/create.php" class="btn btn-warning fw-bold">Új autó felvitele</a>
        <?php endif ?>
    </div>
    
    <!-- Szűrő blokk -->
    <form id="filterForm" action="/" method="GET" class="row" novalidate>
        <div class="d-none d-lg-block col-lg-6"></div>
        <div class="col-12 col-lg-6 d-flex flex-wrap align-items-center justify-content-between p-3 rounded-3">
            <!-- Férőhely -->
            <div class="d-flex align-items-center mb-2">
                <input type="number" class="form-control mx-2 text-center" placeholder="0" name="passengers" value="<?= $filters["passengers"] ?>" min="0" max="20">
                <span class="text-white ms-2 text-nowrap">min. férőhely</span>
            </div>

            <!-- Dátum választó -->
            <div class="d-flex align-items-center mb-2">
                <span class="text-white mx-2">Ettől:</span>
                <input type="date" class="form-control text-center" name="date_from" value="<?= $filters["date_from"] ?>">
                <span class="text-white mx-2">Eddig:</span>
                <input type="date" class="form-control text-center" name="date_to" value="<?= $filters["date_to"] ?>">
            </div>

            <!-- Váltó típusa -->
            <div class="mb-2 mb-md-0">
                <select class="form-select form-select-sm" name="transmission">
                    <option <?= $filters["transmission"] == "" ? "selected" : "" ?> value="">Váltó típusa</option>
                    <option <?= $filters["transmission"] == "Manual" ? "selected" : "" ?> value="Manual">Manuális</option>
                    <option <?= $filters["transmission"] == "Automatic" ? "selected" : "" ?> value="Automatic">Automata</option>
                </select>
            </div>

            <!-- Ár tartomány -->
            <div class="d-flex align-items-center mb-2">
                <input type="number" class="form-control text-center" placeholder="0" name="price_from" value="<?= $filters["price_from"] ?>" min="0" max="500000">
                <span class="text-white mx-2">-</span>
                <input type="number" class="form-control text-center" placeholder="50000" name="price_to" value="<?= $filters["price_to"] ?>" min="0" max="500000">
                <span class="text-white ms-2">Ft</span>
            </div>

            <div>
                <button class="btn btn-warning fw-bold px-4">Szűrés</button>
                <a href="/" class="btn px-2 btn-dark fw-bold">Szűrés törlése</a>
            </div>
        </div>
    </form>
    
    <!-- Autók -->
    <?php if (count($cars) > 0) : ?>
    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 row-cols-lg-4 g-4 mb-2">
        <?php foreach($cars as $car) : ?>
        <div class="col">
            <div class="car-card">
                <a href="/pages/car_details.php?id=<?= $car["id"] ?>">
                    <img src="<?= $car["image"] ?>" alt="<?= $car["brand"]." ".$car["model"] ?>">
                </a>
                <?php if($user && $user["admin"]) : ?>
                    <div class="action-buttons">
                        <button type="button" data-bs-toggle="modal" data-bs-target="#confirmDelete"
                            href="/actions/delete.php?id=<?= $car["id"] ?>" 
                            class="btn btn-sm btn-danger fw-bold">
                            Törlés
                        </button>
                        <a href="/pages/edit.php?id=<?= $car["id"] ?>" class="btn btn-sm btn-light fw-bold">Szerkeszt</a>
                    </div>
                <?php endif ?>
                <div class="car-details p-2">
                    <div class="d-flex flex-wrap justify-content-between align-items-center">
                        <h5 class="me-1 mb-0"><?= $car["brand"] ?> <span class="fw-bold"><?= $car["model"] ?></span></h5>
                        <div class="fw-bold fs-4"><?= number_format($car["daily_price_huf"], 0, ",", ".") ?> Ft</div>
                    </div>
                    <p><?= $car["passengers"] ?> férőhely - <?= transmissionToHun($car["transmission"]) ?></p>
                    <a href="/pages/car_details.php?id=<?= $car["id"] ?>" class="btn btn-sm btn-warning fw-bold">Foglalás</a>
                </div>
            </div>
        </div>
        <?php endforeach ?>
    </div>
    <?php else : ?>
    <h3 class="text-muted fst-italic">Nem találhatók autók. Esetleg próbálkozz más szűrési feltételekkel.</h3>
    <?php endif ?>
</main>

<?php modal_delete("/actions/delete.php?id=".$car["id"], "Törölve lesz a kocsihoz tartozó összes foglalás is.") ?>

<?php page_end() ?>
