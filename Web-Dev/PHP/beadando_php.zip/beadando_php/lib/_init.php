<?php

// Import tools
require_once(dirname(__DIR__) . "/lib/utils/tools.php");

// Session
session_start();
$user = get_session_data("user");

// Prepare storage access
require_once(dirname(__DIR__) . "/lib/utils/storage.php");
$carIO = new JsonIO(dirname(__DIR__) . "/storage/cars.json");
$Car = new Storage($carIO);
$userIO = new JsonIO(dirname(__DIR__) . "/storage/users.json");
$User = new Storage($userIO);
$rentalIO = new JsonIO(dirname(__DIR__) . "/storage/rentals.json");
$Rental = new Storage($rentalIO);

// Import partial pages
require_once(dirname(__DIR__) . "/pages/partials/page_start.php");
require_once(dirname(__DIR__) . "/pages/partials/page_end.php");
require_once(dirname(__DIR__) . "/pages/partials/page_header.php");
require_once(dirname(__DIR__) . "/pages/partials/modal_delete.php");
