<?php

function set_session_data($var, $value = []) {
    $res = $_SESSION[$var] ?? $value;
    $_SESSION[$var] = $value;
    return $res;
}

function get_session_data($var) {
    return $_SESSION[$var] ?? null;
}

function set_flash_data($key, $value) {
    set_session_data($key, $value);
}

function get_flash_data($key) {
    $value = get_session_data($key);
    unset($_SESSION[$key]);
    return $value;
}

function redirect($location)
{
    header("Location: $location");
    die;
}

function transmissionToHun($trans) {
    switch (strtolower($trans)) {
        case "automatic":
            return "automata";
            break;
        case "manual":
            return "manuális";
            break;
        default:
            return "ismeretlen";
    }
}
function fuelTypeToHun($fuel) {
    switch (strtolower($fuel)) {
        case "petrol":
            return "benzin";
            break;
        case "electric":
            return "elektromos";
            break;
        default:
            return "ismeretlen";
    }
}
function isRentalConflict($rental, $newRental) {
    $existingStart = new DateTime($rental['date_from']);
    $existingEnd = new DateTime($rental['date_to']);
    $newStart = new DateTime($newRental['date_from']);
    $newEnd = new DateTime($newRental['date_to']);
    
    if (!($newEnd < $existingStart || $newStart > $existingEnd)) return true; 
    else return false;
}
