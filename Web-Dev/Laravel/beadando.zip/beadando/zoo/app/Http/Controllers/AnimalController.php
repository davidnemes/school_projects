<?php

namespace App\Http\Controllers;

use App\Models\Animal;
use App\Http\Requests\StoreAnimalRequest;
use App\Http\Requests\UpdateAnimalRequest;
use App\Models\Enclosure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class AnimalController extends Controller
{
    private $validation = [
        [
            "name" => "required|string|min:3|max:100",
            "species" => "required|string|min:3|max:100",
            "is_predator" => "nullable|string",
            "enclosure_id" => "required|exists:enclosures,id",
            "file" => "file|mimes:jpeg,png,jpg,webp,gif,svg|max:2048"
        ],
        [
            "required" => ":attribute megadása kötelező!",
            "string" => ":attribute csak szöveg lehet!",
            "min" => ":attribute minimum :min karakter!",
            "max" => ":attribute maximum :max karakter!",
            "exists" => ":attribute nem létezik",
            "mimes" => ":attribute kiterjesztése nem megfelelő!",
            "file.max" => ":attribute mérete túl nagy!",
        ],
        [
            "name" => "A név",
            "species" => "Az állat faja",
            "is_predator" => "A Ragadozó tulajdonság",
            "enclosure_id" => "A kifutó",
            "file" => "A fájl",
        ]
    ];


    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // Authorization
        if (!Auth::user()->admin) abort(401);

        $enclosures = Enclosure::all();
        return view("animals.animal_form", ["enclosures" => $enclosures]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Authorization
        if (!Auth::user()->admin) abort(401);

        // Validation
        $validated = $request->validate(
            $this->validation[0],
            $this->validation[1],
            $this->validation[2]
        );
        $validated['is_predator'] = $request->has('is_predator');

        $enclosure = Enclosure::find($validated['enclosure_id']);

        $error = $this->checkEnclosure($enclosure, $validated['is_predator']);
        if (count($error) > 0) {
            return back()
                ->withInput()
                ->withErrors($error);
        }

        $validated["born_at"] = now();

        if ($request->hasFile('file')) {
            $filename = $request->file('file')->store('animals', 'public');

            $validated['filename'] = $request->file('file')->getClientOriginalName();
            $validated['filename_hash'] = $filename;
        }
        // dd($validated);

        $animal = Animal::create($validated);

        return redirect()->route('enclosures.show', ['enclosure' => $enclosure->id]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $animal = Animal::findOrFail($id);

        // Authorization
        if (!Auth::user()->admin) abort(401);

        $enclosures = Enclosure::all();
        return view("animals.animal_form", ["enclosures" => $enclosures, 'animal' => $animal]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $animal = Animal::findOrFail($id);

        // Authorization
        if (!Auth::user()->admin) abort(401);

        // Validation
        $validated = $request->validate(
            $this->validation[0],
            $this->validation[1],
            $this->validation[2]
        );
        $validated['is_predator'] = $request->has('is_predator');

        $enclosure = Enclosure::find($validated['enclosure_id']);

        $error = $this->checkEnclosure($enclosure, $validated['is_predator'], true);
        if (count($error) > 0) {
            return back()
                ->withInput()
                ->withErrors($error);
        }

        if ($request->hasFile('file')) {
            if ($animal->filename_hash && Storage::disk('public')->exists($animal->filename_hash)) {
                Storage::disk('public')->delete($animal->filename_hash);
            }
            $filename = $request->file('file')->store('animals', 'public');

            $validated['filename'] = $request->file('file')->getClientOriginalName();
            $validated['filename_hash'] = $filename;
        }
        // dd($validated);

        $animal->update($validated);

        return redirect()->route('enclosures.show', ['enclosure' => $enclosure->id]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $animal = Animal::findOrFail($id);

        // Authorization
        if (!Auth::user()->admin) abort(401);

        $enclosure_id = $animal->enclosure->id;
        $animal->update([ "enclosure_id" => null ]);
        $animal->delete();
        return redirect()->route('enclosures.show', ['enclosure' => $enclosure_id]);
    }

    /**
     * Lists archived animals.
     */
    public function arhived()
    {
        // Authorization
        if (!Auth::user()->admin) abort(401);

        $archivedAnimals = Animal::onlyTrashed()->get();
        return view("animals.animal_archived", ["archivedAnimals" => $archivedAnimals]);
    }

    /**
     * Lists archived animals.
     */
    public function restore(string $id)
    {
        $animal = Animal::withTrashed()->findOrFail($id);

        // Authorization
        if (!Auth::user()->admin) abort(401);

        foreach (Enclosure::all() as $enclosure) {
            if ($enclosure->animals->count() == $enclosure->limit) continue;
            if ($enclosure->animals->first()->is_predator == $animal->is_predator) {
                $animal->update([ "enclosure_id" => $enclosure->id ]);
                break;
            }
        }
        if ($animal->enclosure_id == null) {
            return redirect()->route("animals.arhived")->with('error', 'Nincs olyan kifutó, ahova helyezni lehetne az állatot!');
        }

        $animal->restore();
        return redirect()->route('enclosures.show', ['enclosure' => $animal->enclosure->id]);
    }


    /////////////////////////////////////////////////
    // HELPERS
    /////////////////////////////////////////////////


    /**
     * Checks enclosure for animal.
     */
    private function checkEnclosure(Enclosure $enclosure, $is_predator, $is_updating = false): Array
    {
        if ($enclosure->animals->count() > 0) {
            if ($enclosure->animals->count() == $enclosure->limit && !$is_updating) {
                return ['enclosure_id' => 'Az adott kifutó tele van!'];
            }
            $existingIsPredator = $enclosure->animals->first()->is_predator;

            if ($is_predator !== $existingIsPredator) {

                return ['is_predator' => 'Az adott kifutóban más típusú állatok vannak (ragadozó/növényevő).'];
            }
        }
        return [];
    }
}
