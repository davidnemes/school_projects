<?php

namespace App\Http\Controllers;

use App\Models\Enclosure;
use App\Http\Requests\StoreEnclosureRequest;
use App\Http\Requests\UpdateEnclosureRequest;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class EnclosureController extends Controller
{
    private $validation = [
        [
            "name" => "required|string|min:3|max:100",
            "limit" => "required|integer|min:5|max:15",
            "feeding_at" => "required|date_format:H:i",
        ],
        [
            "required" => ":attribute megadása kötelező!",
            "string" => ":attribute csak szöveg lehet!",
            "name.min" => ":attribute minimum :min karakter!",
            "name.max" => ":attribute maximum :max karakter!",
            "integer" => ":attribute csak szám lehet!",
            "limit.min" => ":attribute nem lehet kisebb mint :min.",
            "limit.max" => ":attribute nem lehet nagyobb mint :max.",
            "date_format" => ":attribute formátuma hibás! (pl. 14:30)",
        ],
        [
            "name" => "A név",
            "limit" => "A limit",
            "feeding_at" => "Az etetési időpont",
        ]
    ];
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $user = Auth::user();
        if ($user->admin) {
            $enclosures = Enclosure::query();
        } else {
            $enclosures = $user->enclosures();
        }
        $enclosures = $enclosures->orderBy("name")->paginate(5);
        return view("enclosures.enclosure_index", [ "enclosures" => $enclosures, "error" => $request->input('error') ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        // Authorization
        if (!Auth::user()->admin) abort(401);

        return view("enclosures.enclosure_form");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // Authorization
        if (!Auth::user()->admin) abort(401);

        // Validation
        $validated = $request->validate(
            $this->validation[0],
            $this->validation[1],
            $this->validation[2]
        );

        $enclosure = Enclosure::create($validated);

        return redirect()->route('enclosures.show', [ "enclosure" => $enclosure->id ]);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $enclosure = Enclosure::findOrFail($id);

        // Authorization
        $user = Auth::user();
        if (!$user->admin && !$enclosure->users->contains($user->id)) abort(401);

        return view("enclosures.enclosure_show", [ "enclosure" => $enclosure ]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $enclosure = Enclosure::findOrFail($id);

        // Authorization
        if (!Auth::user()->admin) abort(401);

        $users = [];
        $users[0] = $enclosure->users()->get();
        $users[1] = User::whereNotIn("id", $enclosure->users()->pluck("users.id"))->get();

        return view("enclosures.enclosure_form", [ "enclosure" => $enclosure, "users" => $users ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $enclosure = Enclosure::findOrFail($id);

        // Authorization
        if (!Auth::user()->admin) abort(401);

        // Validation
        $validated = $request->validate(
            $this->validation[0],
            $this->validation[1],
            $this->validation[2]
        );

        $enclosure->update($validated);

        return redirect()->route('enclosures.show', [ "enclosure" => $enclosure->id ]);
    }

    /**
     * Add user to Enclosure.
     */
    public function addUser(Request $request, string $id)
    {
        $enclosure = Enclosure::findOrFail($id);

        // Authorization
        if (!Auth::user()->admin) abort(401);

        $validated = $request->validate([ "userId" => "required|integer|exists:users,id" ]);
        $enclosure->users()->attach($validated["userId"]);

        return redirect()->route("enclosures.edit", ["enclosure" => $enclosure]);

    }

    /**
     * Add user to Enclosure.
     */
    public function removeUser(Request $request, string $id)
    {
        $enclosure = Enclosure::findOrFail($id);

        // Authorization
        if (!Auth::user()->admin) abort(401);

        $validated = $request->validate([ "userId" => "required|integer|exists:users,id" ]);
        $enclosure->users()->detach($validated["userId"]);

        return redirect()->route("enclosures.edit", ["enclosure" => $enclosure]);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $enclosure = Enclosure::findOrFail($id);

        // Authorization
        if (!Auth::user()->admin) abort(401);

        if ($enclosure->animals->count() > 0) {
            return redirect()->route("enclosures.index")->with('error', 'A kifutó tartalmaz állatokat!');
        }

        $enclosure->users()->detach();

        $enclosure->delete();
        return redirect()->route("enclosures.index");
    }
}
