<?php

use App\Http\Controllers\AnimalController;
use App\Http\Controllers\EnclosureController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect("/login");
});

Route::middleware('auth')->group(function() {
    Route::resource('enclosures', EnclosureController::class);

    Route::post('/enclosures/{enclosure}/addUser', [EnclosureController::class, "addUser" ])->name("enclosures.addUser");
    Route::post('/enclosures/{enclosure}/removeUser', [EnclosureController::class, "removeUser" ])->name("enclosures.removeUser");

    // Route::resource('animals', AnimalController::class);
    Route::get('/animals/create', [AnimalController::class, 'create'])->name('animals.create');
    Route::post('/animals', [AnimalController::class, 'store'])->name('animals.store');
    Route::get('/animals/{animal}/edit', [AnimalController::class, 'edit'])->name('animals.edit');
    Route::put('/animals/{animal}', [AnimalController::class, 'update'])->name('animals.update');
    Route::delete('/animals/{animal}', [AnimalController::class, 'destroy'])->name('animals.destroy');
    Route::get('/animals/arhived', [AnimalController::class, 'arhived'])->name('animals.arhived');
    Route::put('/animals/{animal}/restore', [AnimalController::class, 'restore'])->name('animals.restore');

});

Route::get('/dashboard', function () {
    return redirect("/enclosures");
})->name("dashboard");
// Route::get('/dashboard', function () {
//     return view('dashboard');
// })->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
