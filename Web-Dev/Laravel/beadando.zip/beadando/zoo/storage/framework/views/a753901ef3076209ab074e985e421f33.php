<?php $__env->startSection('title', 'Kifutó adatai'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">

    <ul class="list-group">
        <li class="list-group-item">Név: <strong><?php echo e($enclosure->name); ?></strong></li>
        <li class="list-group-item">Limit: <strong><?php echo e($enclosure->limit); ?></strong></li>
        <li class="list-group-item">Elhelyezett állatok száma: <strong><?php echo e($enclosure->animals->count()); ?></strong></li>
        <li class="list-group-item">Állatok típusa:
            <?php if($enclosure->animals->count() == 0): ?>
            <?php elseif($enclosure->animals->first()->is_predator): ?>
                <strong class="alert-danger p-2">Ragadozó</strong>
            <?php else: ?>
                <strong class="alert-success p-2">Növényevő</strong>
            <?php endif; ?>
        </li>
      </ul>
    <h2 class="ps-3 mt-4">Állatok</h2>
    <hr />

    <div class="table-responsive">
        <table class="table align-middle table-hover">
            <thead class="text-center table-light">
                <tr>
                    <th></th>
                    <th>Név</th>
                    <th>Faj</th>
                    <th>Született</th>
                    <th></th>
                </tr>
            </thead>
            <tbody class="text-center">

            <?php $__currentLoopData = $enclosure->animals->sortBy(['species', 'born_at']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>

                        <img src="<?php echo e($animal->filename_hash
                            ? Storage::url($animal->filename_hash)
                            : asset('storage/paw-solid.svg')); ?>"
                            alt="Állat képe"
                            width="80" height="80"
                            class="rounded shadow-sm object-fit-cover" />
                    </td>
                    <td> <?php echo e($animal->name); ?></td>
                    <td> <?php echo e($animal->species); ?></td>
                    <td> <?php echo e($animal->born_at); ?></td>

                    <td>
                        <?php if(Auth::user()->admin): ?>
                            <form class="d-inline" method="POST" action="<?php echo e(route('animals.destroy', ["animal" => $animal->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button onclick="return confirm('Biztosan archiválod?')" class="btn btn-outline-danger ">
                                    <i class="fa-solid fa-trash fa-fw"></i>
                                </button>
                            </form>

                            <a class="btn btn-outline-warning " href="<?php echo e(route("animals.edit", ["animal" => $animal->id])); ?>">
                                <i class="fa-solid fa-pen-to-square fa-fw"></i>
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\nemes\SULI\szerveroldali\beadando\zoo\resources\views/enclosures/enclosure_show.blade.php ENDPATH**/ ?>