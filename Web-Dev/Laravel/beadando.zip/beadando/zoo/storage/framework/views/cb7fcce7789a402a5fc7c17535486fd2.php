<?php $__env->startSection('title', 'Kifutók'); ?>

<?php $__env->startSection('content'); ?>
<h1 class="ps-3">Kifutók</h1>
<hr />
<div class="table-responsive">
    <table class="table align-middle table-hover">
        <thead class="text-center table-light">
            <tr>
                <th style="width: 30%">Név</th>
                <th style="width: 20%">Limit</th>
                <th style="width: 30%">Elhelyezett állatok száma</th>
                <th style="width: 20%"></th>
            </tr>
        </thead>
        <tbody class="text-center">
            <?php $__currentLoopData = $enclosures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enclosure): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <tr>
                        <td>
                            <div><?php echo e($enclosure->name); ?></div>
                            
                        </td>
                        <td>
                            <span class="badge rounded-pill bg-danger fs-6"><?php echo e($enclosure->limit); ?></span>
                        </td>
                        <td>
                            <span class="badge rounded-pill bg-info fs-6"><?php echo e($enclosure->animals->count()); ?></span>
                        </td>
                        <td>
                            <button class="btn btn-outline-info ">
                                <i class="fa-solid fa-angles-right fa-fw"></i>
                            </button>

                            <?php if(Auth::user()->admin): ?>
                                <button class="btn btn-outline-danger ">
                                    <i class="fa-solid fa-trash fa-fw"></i>
                                </button>

                                <button class="btn btn-outline-warning ">
                                    <i class="fa-solid fa-pen-to-square fa-fw"></i>
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($enclosures->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\nemes\SULI\szerveroldali\beadando\zoo\resources\views/enclosures/index.blade.php ENDPATH**/ ?>