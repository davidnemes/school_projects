<?php $__env->startSection('title', isset($enclosure) ? 'Kifutó szerkesztése' : 'Új Kifutó'); ?>

<?php $__env->startSection('content'); ?>

<h1 class="ps-3"><?php echo e(isset($enclosure) ? 'Kifutó szerkesztése' : 'Új Kifutó'); ?></h1>
<hr />
<form class="container" method="POST" action="<?php echo e(isset($enclosure) ? route('enclosures.update', ['enclosure' => $enclosure->id]) : route('enclosures.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if(isset($enclosure)): ?>
        <?php echo method_field("PUT"); ?>
    <?php endif; ?>
    <div class="mb-3">
        <label for="name" class="form-label">Kifutó neve:</label>
        <input
            type="text"
            class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            placeholder="Név"
            name="name"
            id="name"
            value="<?php echo e(old("name", $enclosure->name ?? '')); ?>"
        />
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label for="limit" class="form-label">Kifutó limite:</label>
        <input
            type="number"
            class="form-control <?php $__errorArgs = ['limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            placeholder="Limit"
            name="limit"
            id="limit"
            value="<?php echo e(old("limit", $enclosure->limit ?? '')); ?>"
        />
        <?php $__errorArgs = ['limit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="mb-3">
        <label for="feeding_at" class="form-label">Etetési idő</label>
        <input
            type="time"
            class="form-control <?php $__errorArgs = ['feeding_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            name="feeding_at"
            id="feeding_at"
            value="<?php echo e(old("feeding_at", $enclosure->feeding_at ?? '')); ?>"
        />
        <?php $__errorArgs = ['feeding_at'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="row">
        <button type="submit" class="btn btn-primary">Mentés</button>
    </div>
</form>

<?php if(isset($enclosure)): ?>
<div>
    <h2 class="ps-3 mt-4">Gondozók</h2>
    <hr />
    <div class="container">

        <h3>Hozzárendelt gondozók:</h3>
        <ul class="list-group list-group-flush">
            <?php if(count($users[0]) == 0): ?>
                <li class="list-group-item">
                    <i>Nincs hozzárendelve dolgozó</i>
                </li>
            <?php endif; ?>
            <?php $__currentLoopData = $users[0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <form class="d-flex justify-content-between" method="POST" action="<?php echo e(route('enclosures.removeUser', ['enclosure' => $enclosure->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="d-inline">
                            <?php echo e($user->name); ?> - <?php echo e($user->id); ?>

                        </div>
                        <input type="hidden" value="<?php echo e($user->id); ?>" name="userId">
                        <button class="btn btn-outline-danger ">
                            <i class="fa-solid fa-trash fa-fw"></i>
                        </button>
                    </form>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
        <h3>További gondozók:</h3>
        <ul class="list-group list-group-flush">
            <?php if(count($users[1]) == 0): ?>
                <li class="list-group-item">
                    <i>Nincs további dolgozó</i>
                </li>
            <?php endif; ?>
            <?php $__currentLoopData = $users[1]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <form class="d-flex justify-content-between" method="POST" action="<?php echo e(route('enclosures.addUser', ['enclosure' => $enclosure->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="d-inline">
                            <?php echo e($user->name); ?> - <?php echo e($user->id); ?>

                        </div>
                        <input type="hidden" value="<?php echo e($user->id); ?>" name="userId">
                        <button class="btn btn-outline-success pull-right">
                            <i class="fa-solid fa-plus fa-fw"></i>
                        </button>
                    </form>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>

</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\nemes\SULI\szerveroldali\beadando\zoo\resources\views/enclosures/enclosure_form.blade.php ENDPATH**/ ?>