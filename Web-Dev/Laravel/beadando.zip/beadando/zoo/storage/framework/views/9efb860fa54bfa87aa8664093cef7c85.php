<?php $__env->startSection('title', 'Archivált Állatok'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <h2 class="ps-3 mt-4">Arhivált Állatok</h2>
    <hr />
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            Hiba: <b><?php echo e(session('error')); ?></b>
        </div>
    <?php endif; ?>

    <div class="table-responsive">
        <table class="table align-middle table-hover">
            <thead class="text-center table-light">
                <tr>
                    <th>Név</th>
                    <th>Faj</th>
                    <th>Arhivált</th>
                    <th>Helyreállítás</th>
                </tr>
            </thead>
            <tbody class="text-center">

            <?php $__currentLoopData = $archivedAnimals->sortByDesc("deleted_at"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    
                    <td> <?php echo e($animal->name); ?></td>
                    <td> <?php echo e($animal->species); ?></td>
                    <td> <?php echo e($animal->deleted_at); ?></td>
                    <td>
                        <form class="d-inline" method="POST" action="<?php echo e(route('animals.restore', ["animal" => $animal->id])); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <button class="btn btn-outline-info">
                                <i class="fa-solid fa-heart fa-fw"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\nemes\SULI\szerveroldali\beadando\zoo\resources\views/animals/animal_archived.blade.php ENDPATH**/ ?>