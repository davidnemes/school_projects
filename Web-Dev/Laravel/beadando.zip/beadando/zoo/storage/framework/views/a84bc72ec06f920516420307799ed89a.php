<?php $__env->startSection('title', 'Új Kifutó'); ?>

<?php $__env->startSection('content'); ?>

<h1 class="ps-3">Új Kifutó</h1>
<hr />
<form class="container" method="POST" action="<?php echo e(route("enclosures.store")); ?>">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="name" class="form-label">Kifutó neve:</label>
        <input
            type="text"
            class="form-control"
            placeholder="Név"
            name="name"
            id="name"
        />
    </div>
    <div class="mb-3">
        <label for="name" class="form-label">Kifutó limite:</label>
        <input
            type="number"
            class="form-control"
            placeholder="Limit"
            name="limit"
            id="limit"
        />
    </div>
    <div class="mb-3">
        <label for="time" class="form-label">Etetési idő</label>
        <input
            type="time"
            class="form-control"
            name="time"
            id="time"
        />
    </div>
    <div class="row">
        <button type="submit" class="btn btn-primary">Mentés</button>
    </div>
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\nemes\SULI\szerveroldali\beadando\zoo\resources\views/enclosures/form.blade.php ENDPATH**/ ?>