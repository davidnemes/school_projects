<?php

namespace Database\Seeders;

use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        User::factory()->create([
            'name' => 'Super Admin',
            'email' => 'admin@admin.hu',
            'password' => Hash::make('admin'),
            'admin' => true,
        ]);
        User::factory()->create([
            'name' => 'Casual Cathrine',
            'email' => 'user@user.hu',
            'password' => Hash::make('user'),
            'admin' => false,
        ]);
        User::factory(5)->create();

        $this->call([
            EnclosureSeeder::class,
            AnimalSeeder::class,
        ]);
    }
}
