<?php

namespace Database\Seeders;

use App\Models\Animal;
use App\Models\Enclosure;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AnimalSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $enclosures = Enclosure::all();
        foreach ($enclosures as $index => $enclosure) {
            Animal::factory(5)->for($enclosure)->create([
                "is_predator" => $index % 2 == 0
            ]);
        }
    }
}
