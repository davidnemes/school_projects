@extends('layout')

@section('title', isset($enclosure) ? 'Kifutó szerkesztése' : 'Új Kifutó')

@section('content')

<h1 class="ps-3">{{ isset($enclosure) ? 'Kifutó szerkesztése' : 'Új Kifutó' }}</h1>
<hr />
<form class="container" method="POST" action="{{ isset($enclosure) ? route('enclosures.update', ['enclosure' => $enclosure->id]) : route('enclosures.store') }}">
    @csrf
    @isset($enclosure)
        @method("PUT")
    @endisset
    <div class="mb-3">
        <label for="name" class="form-label">Kifutó neve:</label>
        <input
            type="text"
            class="form-control @error('name') is-invalid @enderror"
            placeholder="Név"
            name="name"
            id="name"
            value="{{ old("name", $enclosure->name ?? '') }}"
        />
        @error('name')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
    <div class="mb-3">
        <label for="limit" class="form-label">Kifutó limite:</label>
        <input
            type="number"
            class="form-control @error('limit') is-invalid @enderror"
            placeholder="Limit"
            name="limit"
            id="limit"
            value="{{ old("limit", $enclosure->limit ?? '') }}"
        />
        @error('limit')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
    <div class="mb-3">
        <label for="feeding_at" class="form-label">Etetési idő</label>
        <input
            type="time"
            class="form-control @error('feeding_at') is-invalid @enderror"
            name="feeding_at"
            id="feeding_at"
            value="{{ old("feeding_at", $enclosure->feeding_at ?? '') }}"
        />
        @error('feeding_at')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
    <div class="row">
        <button type="submit" class="btn btn-primary">Mentés</button>
    </div>
</form>

@isset($enclosure)
<div>
    <h2 class="ps-3 mt-4">Gondozók</h2>
    <hr />
    <div class="container">

        <h3>Hozzárendelt gondozók:</h3>
        <ul class="list-group list-group-flush">
            @if(count($users[0]) == 0)
                <li class="list-group-item">
                    <i>Nincs hozzárendelve dolgozó</i>
                </li>
            @endif
            @foreach ($users[0] as $user)
                <li class="list-group-item">
                    <form class="d-flex justify-content-between" method="POST" action="{{ route('enclosures.removeUser', ['enclosure' => $enclosure->id]) }}">
                        @csrf
                        <div class="d-inline">
                            {{ $user->name }} - {{ $user->id }}
                        </div>
                        <input type="hidden" value="{{ $user->id }}" name="userId">
                        <button class="btn btn-outline-danger ">
                            <i class="fa-solid fa-trash fa-fw"></i>
                        </button>
                    </form>
                </li>
            @endforeach
        </ul>
        <h3>További gondozók:</h3>
        <ul class="list-group list-group-flush">
            @if(count($users[1]) == 0)
                <li class="list-group-item">
                    <i>Nincs további dolgozó</i>
                </li>
            @endif
            @foreach ($users[1] as $user)
                <li class="list-group-item">
                    <form class="d-flex justify-content-between" method="POST" action="{{ route('enclosures.addUser', ['enclosure' => $enclosure->id]) }}">
                        @csrf
                        <div class="d-inline">
                            {{ $user->name }} - {{ $user->id }}
                        </div>
                        <input type="hidden" value="{{ $user->id }}" name="userId">
                        <button class="btn btn-outline-success pull-right">
                            <i class="fa-solid fa-plus fa-fw"></i>
                        </button>
                    </form>
                </li>
            @endforeach
        </ul>
    </div>

</div>
@endisset

@endsection
