{{-- @dd($tickets) --}}

@extends('layout')

@section('title', 'Kifutók')

@section('content')
<h1 class="ps-3">Kifutók</h1>
<hr />
@if(session('error'))
    <div class="alert alert-danger">
        Hiba: <b>{{ session('error') }}</b>
    </div>
@endif
<div class="table-responsive">
    <table class="table align-middle table-hover">
        <thead class="text-center table-light">
            <tr>
                <th style="width: 30%">Név</th>
                <th style="width: 20%">Limit</th>
                <th style="width: 30%">Elhelyezett állatok száma</th>
                <th style="width: 20%"></th>
            </tr>
        </thead>
        <tbody class="text-center">
            @foreach ($enclosures as $enclosure)
                <tr>
                    <td>
                        <div>{{ $enclosure->name }}</div>
                    </td>
                    <td>
                        <span class="badge rounded-pill bg-danger fs-6">{{ $enclosure->limit }}</span>
                    </td>
                    <td>
                        <span class="badge rounded-pill bg-info fs-6">{{ $enclosure->animals->count() }}</span>
                    </td>
                    <td>
                        <a class="btn btn-outline-info" href="{{ route("enclosures.show", ["enclosure" => $enclosure->id]) }}">
                            <i class="fa-solid fa-angles-right fa-fw"></i>
                        </a>

                        @if(Auth::user()->admin)
                            <form class="d-inline" method="POST" action="{{ route('enclosures.destroy', ["enclosure" => $enclosure->id]) }}">
                                @csrf
                                @method('DELETE')
                                <button onclick="return confirm('Biztosan archiválod?')" class="btn btn-outline-danger ">
                                    <i class="fa-solid fa-trash fa-fw"></i>
                                </button>
                            </form>

                            <a class="btn btn-outline-warning " href="{{ route("enclosures.edit", ["enclosure" => $enclosure->id]) }}">
                                <i class="fa-solid fa-pen-to-square fa-fw"></i>
                            </a>
                        @endif
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    {{ $enclosures->links() }}
</div>
@endsection
