@extends('layout')

@section('title', 'Kifutó adatai')

@section('content')

<div class="container">

    <ul class="list-group">
        <li class="list-group-item">Név: <strong>{{ $enclosure->name }}</strong></li>
        <li class="list-group-item">Limit: <strong>{{ $enclosure->limit }}</strong></li>
        <li class="list-group-item">Elhelyezett állatok száma: <strong>{{ $enclosure->animals->count() }}</strong></li>
        <li class="list-group-item">Állatok típusa:
            @if ($enclosure->animals->count() == 0)
            @elseif ($enclosure->animals->first()->is_predator)
                <strong class="alert-danger p-2">Ragadozó</strong>
            @else
                <strong class="alert-success p-2">Növényevő</strong>
            @endif
        </li>
      </ul>
    <h2 class="ps-3 mt-4">Állatok</h2>
    <hr />

    <div class="table-responsive">
        <table class="table align-middle table-hover">
            <thead class="text-center table-light">
                <tr>
                    <th></th>
                    <th>Név</th>
                    <th>Faj</th>
                    <th>Született</th>
                    <th></th>
                </tr>
            </thead>
            <tbody class="text-center">

            @foreach($enclosure->animals->sortBy(['species', 'born_at']) as $animal)
                <tr>
                    <td>

                        <img src="{{ $animal->filename_hash
                            ? Storage::url($animal->filename_hash)
                            : asset('storage/paw-solid.svg') }}"
                            alt="Állat képe"
                            width="80" height="80"
                            class="rounded shadow-sm object-fit-cover" />
                    </td>
                    <td> {{ $animal->name }}</td>
                    <td> {{ $animal->species }}</td>
                    <td> {{ $animal->born_at }}</td>

                    <td>
                        @if(Auth::user()->admin)
                            <form class="d-inline" method="POST" action="{{ route('animals.destroy', ["animal" => $animal->id]) }}">
                                @csrf
                                @method('DELETE')
                                <button onclick="return confirm('Biztosan archiválod?')" class="btn btn-outline-danger ">
                                    <i class="fa-solid fa-trash fa-fw"></i>
                                </button>
                            </form>

                            <a class="btn btn-outline-warning " href="{{ route("animals.edit", ["animal" => $animal->id]) }}">
                                <i class="fa-solid fa-pen-to-square fa-fw"></i>
                            </a>
                        @endif
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
</div>


@endsection
