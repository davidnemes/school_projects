@extends('layout')

@section('title', isset($animal) ? 'Állat szerkesztése' : 'Új Állat')

@section('content')

{{-- @dd($errors) --}}

<h1 class="ps-3">{{ isset($animal) ? 'Állat szerkesztése' : 'Új Állat' }}</h1>
<hr />
<form class="container" enctype="multipart/form-data" method="POST" action="{{ isset($animal) ? route('animals.update', ['animal' => $animal->id]) : route('animals.store') }}">
    @csrf
    @isset($animal)
        @method("PUT")
    @endisset
    <div class="mb-3">
        <label for="name" class="form-label">Állat neve:</label>
        <input
            type="text"
            class="form-control @error('name') is-invalid @enderror"
            placeholder="Név"
            name="name"
            id="name"
            value="{{ old("name", $animal->name ?? '') }}"
        />
        @error('name')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
    <div class="mb-3">
        <label for="species" class="form-label">Állat faja:</label>
        <input
            type="text"
            class="form-control @error('species') is-invalid @enderror"
            placeholder="Faj"
            name="species"
            id="species"
            value="{{ old("species", $animal->species ?? '') }}"
        />
        @error('species')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
    <div class="mb-3 form-check">
        <label for="is_predator" class="form-label">Ragadozó állat</label>
        <input
            type="checkbox"
            class="form-check-input @error('is_predator') is-invalid @enderror"
            name="is_predator"
            id="is_predator"
            @if(old("is_predator", $animal->is_predator ?? false)) checked @endif
        />
        @error('is_predator')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
    <div class="mb-3">
        <select class="form-select @error('enclosure_id') is-invalid @enderror" name="enclosure_id" id="enclosure_id">
            <option value="">< Kifutó ></option>
            @foreach ($enclosures as $enclosure)
                <option value="{{ $enclosure->id }}" @selected(old('enclosure_id', $animal->enclosure_id ?? '') == $enclosure->id)>{{ $enclosure->name }}</option>
            @endforeach
        </select>
        @error('enclosure_id')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
    <div class="mb-3">
        <input name="file" type="file" class="form-control @error('file') is-invalid @enderror" id="file">
        @error('file')
            <div class="invalid-feedback">
                {{ $message }}
            </div>
        @enderror
    </div>
    <div class="row">
        <button type="submit" class="btn btn-primary">Mentés</button>
    </div>
</form>

@endsection
