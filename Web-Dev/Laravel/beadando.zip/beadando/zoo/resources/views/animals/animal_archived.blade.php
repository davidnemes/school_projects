@extends('layout')

@section('title', 'Archivált Állatok')

@section('content')

<div class="container">
    <h2 class="ps-3 mt-4">Arhivált Állatok</h2>
    <hr />
    @if(session('error'))
        <div class="alert alert-danger">
            Hiba: <b>{{ session('error') }}</b>
        </div>
    @endif

    <div class="table-responsive">
        <table class="table align-middle table-hover">
            <thead class="text-center table-light">
                <tr>
                    <th>Név</th>
                    <th>Faj</th>
                    <th>Arhivált</th>
                    <th>Helyreállítás</th>
                </tr>
            </thead>
            <tbody class="text-center">

            @foreach($archivedAnimals->sortByDesc("deleted_at") as $animal)
                <tr>
                    {{-- <td>

                        <img src="{{ $animal->filename_hash
                            ? Storage::url($animal->filename_hash)
                            : asset('storage/paw-solid.svg') }}"
                            alt="Állat képe"
                            width="80" height="80"
                            class="rounded shadow-sm object-fit-cover" />
                    </td> --}}
                    <td> {{ $animal->name }}</td>
                    <td> {{ $animal->species }}</td>
                    <td> {{ $animal->deleted_at }}</td>
                    <td>
                        <form class="d-inline" method="POST" action="{{ route('animals.restore', ["animal" => $animal->id]) }}">
                            @csrf
                            @method('PUT')
                            <button class="btn btn-outline-info">
                                <i class="fa-solid fa-heart fa-fw"></i>
                            </button>
                        </form>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>

</div>


@endsection
