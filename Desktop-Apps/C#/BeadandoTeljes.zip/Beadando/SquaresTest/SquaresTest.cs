using Moq;
using Squares.Model;
using Squares.Persistence;

namespace SquaresTest
{
    [TestClass]
    public class SquaresTest
    {
        private Mock<ISquaresDataAccess> _mock = null!;
        private SquaresGameModel _gameModel = null!;
        private SquaresTable _table = null!; // hozz�f�r�s biztos�t�sa a modelben l�v� t�bl�hoz

        [TestInitialize]
        public void InitDocuStatTest()
        {
            _mock = new Mock<ISquaresDataAccess>();
            _gameModel = new SquaresGameModel(_mock.Object);
        }


        #region Test Table Constructor
        [TestMethod]
        public void TestTable_ConstructorSetFields()
        {
            var table = new SquaresTable(5);

            Assert.AreEqual(5, table.Size);
            Assert.AreEqual(PlayerId.Blue, table.CurrentPlayer);

            var table2 = new SquaresTable(9);
            Assert.AreEqual(9, table2.Size);

            var table3 = new SquaresTable();
            Assert.AreEqual(3, table3.Size);
        }

        [TestMethod]
        public void TestTable_ConstructorInitializePoints()
        {
            var table = new SquaresTable(5);

            SquaresPoint[,] points;
            (points, _) = table.DumpTable();

            for (int i = 0; i < points.GetLength(0); i++)
            {
                for (int j = 0; j < points.GetLength(1); j++)
                {
                    Assert.AreEqual(i, points[i, j].positionX);
                    Assert.AreEqual(j, points[i, j].positionY);
                    Assert.AreNotEqual(null, points[i, j].BottomLine);
                    Assert.AreNotEqual(null, points[i, j].RightLine);
                    Assert.AreEqual(LineState.Empty, points[i, j].BottomLine.State);
                    Assert.AreEqual(LineState.Empty, points[i, j].RightLine.State);
                }
            }
        }

        [TestMethod]
        public void TestTable_ConstructorInitializeSquaresState()
        {
            var table = new SquaresTable(5);

            PlayerId[,] squaresState;
            (_, squaresState) = table.DumpTable();

            for (int i = 0; i < squaresState.GetLength(0); i++)
            {
                for (int j = 0; j < squaresState.GetLength(1); j++)
                {
                    Assert.AreEqual(PlayerId.Nobody, squaresState[i, j]);
                }
            }
        }
        #endregion

        #region Test Table AlterTable
        [TestMethod]
        public void TestTable_AlterTableFillRightLine()
        {
            SquaresTable table = new SquaresTable();
            table.AlterTable("fillRightLine", 0, 0);

            SquaresPoint[,] points;
            (points, _) = table.DumpTable();
            Assert.AreEqual(LineState.Filled, points[0, 0].RightLine.State);
            Assert.AreEqual(1, table.loadEvents?.Count);
        }

        [TestMethod]
        public void TestTable_AlterTableFillBottomLine()
        {
            SquaresTable table = new SquaresTable();
            table.AlterTable("fillBottomLine", 0, 0);

            SquaresPoint[,] points;
            (points, _) = table.DumpTable();
            Assert.AreEqual(LineState.Filled, points[0, 0].BottomLine.State);
            Assert.AreEqual(1, table.loadEvents?.Count);
        }

        [TestMethod]
        public void TestTable_AlterTableFillSquareBlue()
        {
            SquaresTable table = new SquaresTable();
            table.AlterTable("fillSquareBlue", 0, 0);

            PlayerId[,] squaresState;
            (_, squaresState) = table.DumpTable();
            Assert.AreEqual(PlayerId.Blue, squaresState[0, 0]);
            Assert.AreEqual(1, table.loadEvents?.Count);
        }

        [TestMethod]
        public void TestTable_AlterTableFillSquareRed()
        {
            SquaresTable table = new SquaresTable();
            table.AlterTable("fillSquareRed", 0, 0);

            PlayerId[,] squaresState;
            (_, squaresState) = table.DumpTable();
            Assert.AreEqual(PlayerId.Red, squaresState[0, 0]);
            Assert.AreEqual(1, table.loadEvents?.Count);
        }

        [TestMethod]
        public void TestTable_AlterTablePlayerTurns()
        {
            SquaresTable table = new SquaresTable();
            
            table.AlterTable("playerTurns", -1, -1, PlayerId.Blue);
            Assert.AreEqual(PlayerId.Blue, table.CurrentPlayer);
            table.AlterTable("playerTurns", -1, -1, PlayerId.Red);
            Assert.AreEqual(PlayerId.Red, table.CurrentPlayer);
            Assert.AreEqual(2, table.loadEvents?.Count);
        }
        #endregion

        #region Test Table Fill Line
        [TestMethod]
        public void TestTable_FillLine()
        {
            var table = new SquaresTable();
            Assert.IsTrue(table.FillLine(0, 0, LineDirection.Horizontal));
            Assert.IsTrue(table.FillLine(1, 0, LineDirection.Vertical));

            SquaresPoint[,] points;
            (points, _) = table.DumpTable();
            Assert.AreEqual(LineState.Filled, points[0, 0].RightLine.State);
            Assert.AreEqual(LineState.Filled, points[1, 0].BottomLine.State);
        }

        [TestMethod]
        public void TestTable_FillLineFailes()
        {
            var table = new SquaresTable();
            Assert.IsTrue(table.FillLine(1, 0, LineDirection.Vertical));
            Assert.IsFalse(table.FillLine(1, 0, LineDirection.Vertical));

            SquaresPoint[,] points;
            (points, _) = table.DumpTable();
            Assert.AreEqual(LineState.Filled, points[1, 0].BottomLine.State);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidOperationException))]
        public void TestTable_FillLineIllegal()
        {
            var table = new SquaresTable(3);
            table.FillLine(2, 2, LineDirection.Horizontal);
        }
        #endregion

        #region Test Table Check Squares
        [TestMethod]
        public async Task TestTable_CheckSquaresNotAllFilled()
        {
            await LoadTableWithMoves(3, null);
            Assert.AreEqual(0, _table.CheckSquares(1,0, LineDirection.Vertical).Count);

            await LoadTableWithMoves(3, new List<LoadEvent>
            {
                new LoadEvent("fillBottomLine", 0, 0),
                new LoadEvent("fillBottomLine", 2, 0),
                new LoadEvent("fillRightLine", 0, 0),
                new LoadEvent("fillRightLine", 0, 1),
                new LoadEvent("fillRightLine", 1, 0),
                new LoadEvent("fillRightLine", 1, 1),
            });

            Assert.AreEqual(0, _table.CheckSquares(1, 0, LineDirection.Vertical).Count);
        }

        [TestMethod]
        public async Task TestTable_CheckSquaresFill1Square()
        {
            await LoadTableWithMoves(3, new List<LoadEvent>
            {
                new LoadEvent("fillBottomLine", 0, 0),
                new LoadEvent("fillBottomLine", 1, 0),
                new LoadEvent("fillRightLine", 0, 0),
                new LoadEvent("fillRightLine", 0, 1),
                new LoadEvent("playerTurns", -1, -1, PlayerId.Blue)
            });

            Assert.AreEqual(1, _table.CheckSquares(1, 0, LineDirection.Vertical).Count);
            PlayerId[,] squaresState;
            (_, squaresState) = _table.DumpTable();
            Assert.AreEqual(PlayerId.Blue, squaresState[0, 0]);
        }

        [TestMethod]
        public async Task TestTable_CheckSquaresFill2Squares()
        {
            await LoadTableWithMoves(3, new List<LoadEvent>
            {
                new LoadEvent("fillBottomLine", 0, 0), 
                new LoadEvent("fillBottomLine", 1, 0),
                new LoadEvent("fillBottomLine", 2, 0),
                new LoadEvent("fillRightLine", 0, 0),
                new LoadEvent("fillRightLine", 0, 1),
                new LoadEvent("fillRightLine", 1, 0),
                new LoadEvent("fillRightLine", 1, 1),
                new LoadEvent("playerTurns", -1, -1, PlayerId.Red)
            });

            Assert.AreEqual(2, _table.CheckSquares(1, 0, LineDirection.Vertical).Count);
            PlayerId[,] squaresState;
            (_, squaresState) = _table.DumpTable();
            int a = 0;
            Assert.AreEqual(PlayerId.Red, squaresState[0, 0]);
            Assert.AreEqual(PlayerId.Red, squaresState[1, 0]);
        }
        #endregion

        #region Test Table IsGameOver
        [TestMethod]
        public async Task TestTable_IsGameOverNo()
        {
            await LoadTableWithMoves(3, null);

            bool isGameOver;
            (isGameOver, _) = _table.IsGameOver();

            Assert.IsFalse(isGameOver);
        }

        [TestMethod]
        public async Task TestTable_IsGameOverWinnerBlue()
        {
            await LoadTableWithMoves(3, new List<LoadEvent>
            {
                new LoadEvent("fillSquareBlue", 0, 0),
                new LoadEvent("fillSquareBlue", 1, 0),
                new LoadEvent("fillSquareBlue", 0, 1),
                new LoadEvent("fillSquareBlue", 1, 1),
            });

            bool isGameOver;
            PlayerId winner;
            (isGameOver, winner) = _table.IsGameOver();

            Assert.IsTrue(isGameOver);
            Assert.AreEqual(PlayerId.Blue, winner);
        }

        [TestMethod]
        public async Task TestTable_IsGameOverWinnerRed()
        {
            await LoadTableWithMoves(3, new List<LoadEvent>
            {
                new LoadEvent("fillSquareRed", 0, 0),
                new LoadEvent("fillSquareRed", 1, 0),
                new LoadEvent("fillSquareRed", 0, 1),
                new LoadEvent("fillSquareRed", 1, 1),
            });

            bool isGameOver;
            PlayerId winner;
            (isGameOver, winner) = _table.IsGameOver();

            Assert.IsTrue(isGameOver);
            Assert.AreEqual(PlayerId.Red, winner);
        }

        [TestMethod]
        public async Task TestTable_IsGameOverWinnerDraw()
        {
            await LoadTableWithMoves(3, new List<LoadEvent>
            {
                new LoadEvent("fillSquareRed", 0, 0),
                new LoadEvent("fillSquareRed", 1, 0),
                new LoadEvent("fillSquareBlue", 0, 1),
                new LoadEvent("fillSquareBlue", 1, 1),
            });

            bool isGameOver;
            PlayerId winner;
            (isGameOver, winner) = _table.IsGameOver();

            Assert.IsTrue(isGameOver);
            Assert.AreEqual(PlayerId.Nobody, winner);
        }
        #endregion

        #region Test Model NewGame
        [TestMethod]
        public void TestNewGame_InvokesNextTurn()
        {
            PlayerId nextTurnPlayer = PlayerId.Nobody;
            _gameModel.NextTurn += (sender, args) => nextTurnPlayer = args.Player;

            _gameModel.NewGame(5);

            Assert.AreEqual(PlayerId.Blue, nextTurnPlayer); // ezzel az is tesztelve van, hogy kiv�lt�dott-e az esem�ny
        }
        #endregion

        #region Test Model FillLine
        [TestMethod]
        public async Task TestFillLine_Normal()
        {
            await LoadTableWithMoves(5, null);
            PlayerId nextTurnPlayer = PlayerId.Nobody;
            int lineFilledX = -1;
            int lineFilledY = -1;
            LineDirection? lineFilledDirection = null;
            bool isGameOver = false;

            _gameModel.NextTurn += (sender, args) => nextTurnPlayer = args.Player;
            _gameModel.LineFilled += (sender, args) =>
            {
                lineFilledY = args.Y; lineFilledX = args.X; lineFilledDirection = args.Direction;
            };
            _gameModel.GameOver += (sender, args) =>
            {
                isGameOver = args.IsGameOver;
            };

            _gameModel.FillLine(0, 0, LineDirection.Horizontal);

            Assert.AreEqual(PlayerId.Red, nextTurnPlayer); // ezzel az is tesztelve van, hogy kiv�lt�dott-e az esem�ny
            Assert.AreEqual(0, lineFilledX);
            Assert.AreEqual(0, lineFilledY);
            Assert.AreEqual(LineDirection.Horizontal, lineFilledDirection);
            Assert.IsFalse(isGameOver);
        }

        [TestMethod]
        public async Task TestFillLine_Failed()
        {
            await LoadTableWithMoves(5, new List<LoadEvent>
            {
                new LoadEvent("fillBottomLine", 0, 0),
            });

            PlayerId nextTurnPlayer = PlayerId.Nobody;
            bool lineFilled = false;
            bool isGameOver = false;
            int squareFilled = 0;

            _gameModel.NextTurn += (sender, args) => nextTurnPlayer = args.Player;
            _gameModel.LineFilled += (sender, args) =>
            {
                lineFilled = true;
            };
            _gameModel.GameOver += (sender, args) =>
            {
                isGameOver = args.IsGameOver;
            };
            _gameModel.SquareFilled += (sender, args) =>
            {
                squareFilled++;
            };

            _gameModel.FillLine(0, 0, LineDirection.Vertical);

            Assert.AreEqual(PlayerId.Nobody, nextTurnPlayer);
            Assert.IsFalse(lineFilled);
            Assert.IsFalse(isGameOver);
            Assert.AreEqual(0, squareFilled);
        }

        [TestMethod]
        public async Task TestFillLine_Filled1Square()
        {
            await LoadTableWithMoves(5, new List<LoadEvent>
            {
                new LoadEvent("fillBottomLine", 0, 0),
                new LoadEvent("fillBottomLine", 1, 0),
                new LoadEvent("fillRightLine", 0, 0),
                new LoadEvent("playerTurns", -1, -1, PlayerId.Blue),
            });
            PlayerId nextTurnPlayer = PlayerId.Nobody;
            int lineFilledX = -1;
            int lineFilledY = -1;
            LineDirection? lineFilledDirection = null;
            bool isGameOver = false;
            int squareFilledX = -1; int squareFilledY = -1; PlayerId squareFilledPlayer = PlayerId.Nobody;

            _gameModel.NextTurn += (sender, args) => nextTurnPlayer = args.Player;
            _gameModel.LineFilled += (sender, args) =>
            {
                lineFilledY = args.Y; lineFilledX = args.X; lineFilledDirection = args.Direction;
            };
            _gameModel.GameOver += (sender, args) =>
            {
                isGameOver = args.IsGameOver;
            };
            _gameModel.SquareFilled += (sender, args) =>
            {
                squareFilledX = args.X; squareFilledY = args.Y; squareFilledPlayer = args.Player;
            };

            _gameModel.FillLine(0, 1, LineDirection.Horizontal);

            Assert.AreEqual(PlayerId.Nobody, nextTurnPlayer);
            Assert.AreEqual(0, lineFilledX);
            Assert.AreEqual(1, lineFilledY);
            Assert.AreEqual(LineDirection.Horizontal, lineFilledDirection);
            Assert.AreEqual(0, squareFilledX);
            Assert.AreEqual(0, squareFilledY);
            Assert.AreEqual(PlayerId.Blue, squareFilledPlayer);
            Assert.IsFalse(isGameOver);
        }

        [TestMethod]
        public async Task TestFillLine_Filled2Square()
        {
            await LoadTableWithMoves(5, new List<LoadEvent>
            {
                new LoadEvent("fillBottomLine", 0, 0),
                new LoadEvent("fillBottomLine", 2, 0),
                new LoadEvent("fillRightLine", 0, 0),
                new LoadEvent("fillRightLine", 0, 1),
                new LoadEvent("fillRightLine", 1, 0),
                new LoadEvent("fillRightLine", 1, 1),
                new LoadEvent("playerTurns", -1, -1, PlayerId.Red)
            });
            PlayerId nextTurnPlayer = 0;
            int lineFilledX = -1;
            int lineFilledY = -1;
            LineDirection? lineFilledDirection = null;
            bool isGameOver = false;
            int squareFilled = 0;

            _gameModel.NextTurn += (sender, args) => nextTurnPlayer = args.Player;
            _gameModel.LineFilled += (sender, args) =>
            {
                lineFilledY = args.Y; lineFilledX = args.X; lineFilledDirection = args.Direction;
            };
            _gameModel.GameOver += (sender, args) =>
            {
                isGameOver = args.IsGameOver;
            };
            _gameModel.SquareFilled += (sender, args) =>
            {
                squareFilled++;
            };

            _gameModel.FillLine(1, 0, LineDirection.Vertical);

            Assert.AreEqual(PlayerId.Nobody, nextTurnPlayer);
            Assert.AreEqual(1, lineFilledX);
            Assert.AreEqual(0, lineFilledY);
            Assert.AreEqual(LineDirection.Vertical, lineFilledDirection);
            Assert.AreEqual(2, squareFilled);
            Assert.IsFalse(isGameOver);
        }

        [TestMethod]
        public async Task TestFillLine_IsGameOverWin()
        {

            await LoadTableWithMoves(3, new List<LoadEvent>
            {
                new LoadEvent("fillBottomLine", 0, 0),
                new LoadEvent("fillBottomLine", 1, 0),
                new LoadEvent("fillBottomLine", 2, 0),
                new LoadEvent("fillBottomLine", 0, 1),
                new LoadEvent("fillBottomLine", 1, 1),
                new LoadEvent("fillRightLine", 0, 0),
                new LoadEvent("fillRightLine", 1, 0),
                new LoadEvent("fillRightLine", 0, 1),
                new LoadEvent("fillRightLine", 1, 1),
                new LoadEvent("fillRightLine", 0, 2),
                new LoadEvent("fillRightLine", 1, 2),
                new LoadEvent("fillSquareRed", 0, 0),
                new LoadEvent("fillSquareRed", 1, 0),
                new LoadEvent("fillSquareRed", 0, 1),
                new LoadEvent("playerTurns", -1, -1, PlayerId.Red)
            });
            PlayerId nextTurnPlayer = 0;
            int lineFilledX = -1;
            int lineFilledY = -1;
            LineDirection? lineFilledDirection = null;
            bool isGameOver = false;
            PlayerId winnerPlayer = 0;
            int squareFilled = 0;

            _gameModel.NextTurn += (sender, args) => nextTurnPlayer = args.Player;
            _gameModel.LineFilled += (sender, args) =>
            {
                lineFilledY = args.Y; lineFilledX = args.X; lineFilledDirection = args.Direction;
            };
            _gameModel.GameOver += (sender, args) =>
            {
                isGameOver = args.IsGameOver; winnerPlayer = args.Player;
            };
            _gameModel.SquareFilled += (sender, args) =>
            {
                squareFilled++;
            };

            _gameModel.FillLine(2, 1, LineDirection.Vertical);

            Assert.AreEqual(PlayerId.Nobody, nextTurnPlayer);
            Assert.AreEqual(2, lineFilledX);
            Assert.AreEqual(1, lineFilledY);
            Assert.AreEqual(LineDirection.Vertical, lineFilledDirection);
            Assert.AreEqual(1, squareFilled);
            Assert.IsTrue(isGameOver);
            Assert.AreEqual(PlayerId.Red, winnerPlayer);
        }
        [TestMethod]
        public async Task TestFillLine_IsGameOverDraw()
        {

            await LoadTableWithMoves(3, new List<LoadEvent>
            {
                new LoadEvent("fillBottomLine", 0, 0),
                new LoadEvent("fillBottomLine", 1, 0),
                new LoadEvent("fillBottomLine", 2, 0),
                new LoadEvent("fillBottomLine", 0, 1),
                new LoadEvent("fillBottomLine", 1, 1),
                new LoadEvent("fillRightLine", 0, 0),
                new LoadEvent("fillRightLine", 1, 0),
                new LoadEvent("fillRightLine", 0, 1),
                new LoadEvent("fillRightLine", 1, 1),
                new LoadEvent("fillRightLine", 0, 2),
                new LoadEvent("fillRightLine", 1, 2),
                new LoadEvent("fillSquareBlue", 0, 0),
                new LoadEvent("fillSquareBlue", 1, 0),
                new LoadEvent("fillSquareRed", 0, 1),
                new LoadEvent("playerTurns", -1, -1, PlayerId.Red)
            });
            PlayerId nextTurnPlayer = 0;
            int lineFilledX = -1;
            int lineFilledY = -1;
            LineDirection? lineFilledDirection = null;
            bool isGameOver = false;
            PlayerId winnerPlayer = 0;
            int squareFilled = 0;

            _gameModel.NextTurn += (sender, args) => nextTurnPlayer = args.Player;
            _gameModel.LineFilled += (sender, args) =>
            {
                lineFilledY = args.Y; lineFilledX = args.X; lineFilledDirection = args.Direction;
            };
            _gameModel.GameOver += (sender, args) =>
            {
                isGameOver = args.IsGameOver; winnerPlayer = args.Player;
            };
            _gameModel.SquareFilled += (sender, args) =>
            {
                squareFilled++;
            };

            _gameModel.FillLine(2, 1, LineDirection.Vertical);

            Assert.AreEqual(PlayerId.Nobody, nextTurnPlayer);
            Assert.AreEqual(2, lineFilledX);
            Assert.AreEqual(1, lineFilledY);
            Assert.AreEqual(LineDirection.Vertical, lineFilledDirection);
            Assert.AreEqual(1, squareFilled);
            Assert.IsTrue(isGameOver);
            Assert.AreEqual(PlayerId.Nobody, winnerPlayer);
        }
        #endregion

        #region Test Model LoadTable
        [TestMethod]
        public async Task TestLoadTable_RunTableEventsAfterLoad()
        {
            SquaresTable table = new SquaresTable(3);

            table.AlterTable("fillRightLine", 1, 1);
            table.AlterTable("fillRightLine", 1, 2);
            table.AlterTable("fillBottomLine", 1, 1);
            table.AlterTable("fillBottomLine", 2, 1);
            table.AlterTable("fillSquareRed", 1, 1);

            int lineFilled = 0;
            int squareFilled = 0;
            _gameModel.LineFilled += (sender, args) => lineFilled++;
            _gameModel.SquareFilled += (sender, args) => squareFilled++;

            _mock.Setup(fileManager => fileManager.LoadAsync("path")).Returns(Task.FromResult(table));
            await _gameModel.LoadTableAsync("path");

            Assert.AreEqual(4, lineFilled);
            Assert.AreEqual(1, squareFilled);
        }
        #endregion

        #region Helpers
        private async Task LoadTableWithMoves(int size, List<LoadEvent>? moves)
        {
            SquaresTable table = new SquaresTable(size);

            if (moves != null)
            {
                for (int i = 0; i < moves.Count; i++) table.AlterTable(moves[i].action, moves[i].x, moves[i].y, moves[i].player);
            }
            if (table.loadEvents != null) table.loadEvents.Clear();

            _table = table;
            _mock.Setup(fileManager => fileManager.LoadAsync("path")).Returns(Task.FromResult(table));
            await _gameModel.LoadTableAsync("path");
        }
        #endregion
    }
}