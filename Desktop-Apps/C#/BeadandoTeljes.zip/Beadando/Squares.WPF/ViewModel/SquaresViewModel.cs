﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;
using Squares.Model;

namespace Squares.WPF.ViewModel
{
    public class SquaresViewModel : ViewModelBase
    {
        #region Fields
        private SquaresGameModel _model;
        private int _tableSize = 9;
        private PlayerId _currentPlayer;

        #endregion

        #region Properties

        public bool IsGameOver { get; set; }
        public bool IsGameStarted { get; private set; }
        public int TableSize { 
            get { return _tableSize; } 
            private set
            { 
                _tableSize = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(GridPointWidth));
                OnPropertyChanged(nameof(GridPointPosition));
                OnPropertyChanged(nameof(GamePadding));
            } 
        }

        public int NewGameTableSize { get; set; }

        public bool NewGame3x3
        {
            get { return NewGameTableSize == 3; }
            set
            {
                if (NewGameTableSize == 3) return;

                NewGameTableSize = 3;
                OnPropertyChanged();
                OnPropertyChanged(nameof(NewGame5x5));
                OnPropertyChanged(nameof(NewGame9x9));
            }
        }
        public bool NewGame5x5
        {
            get { return NewGameTableSize == 5; }
            set
            {
                if (NewGameTableSize == 5) return;

                NewGameTableSize = 5;
                OnPropertyChanged();
                OnPropertyChanged(nameof(NewGame3x3));
                OnPropertyChanged(nameof(NewGame9x9));
            }
        }
        public bool NewGame9x9
        {
            get { return NewGameTableSize == 9; }
            set
            {
                if (NewGameTableSize == 9) return;

                NewGameTableSize = 9;
                OnPropertyChanged();
                OnPropertyChanged(nameof(NewGame3x3));
                OnPropertyChanged(nameof(NewGame5x5));
            }
        }

        public PlayerId CurrentPlayer
        {
            get { return _currentPlayer; }
            private set
            {
                _currentPlayer = value;
                OnPropertyChanged();
                OnPropertyChanged(nameof(GameBackgroundColor));
            }
        }

        public int GridPointWidth
        {
            get
            {
                if (TableSize == 9) return 30;
                else return 50;
            }
        }
        public int GridPointPosition
        {
            get
            {
                return -(GridPointWidth / 2 - 7);
            }
        }
        public SolidColorBrush GameBackgroundColor
        {
            get
            {
                return CurrentPlayer switch
                {
                    PlayerId.Nobody => new SolidColorBrush(Color.FromRgb(255, 255, 255)),
                    PlayerId.Blue => new SolidColorBrush(Color.FromRgb(191, 223, 255)),
                    PlayerId.Red => new SolidColorBrush(Color.FromRgb(250, 160, 160)),
                    _ => Brushes.Transparent
                };
            }
        }
        public string GamePadding
        {
            get
            {
                if (TableSize == 3) return "150,150,30,30";
                else if (TableSize == 5) return "100,100,30,30";
                else return "70,70,30,30";
            }
        }

        public ObservableCollection<SquaresGridPoint>? GridPoints { get; set; }

        public DelegateCommand? NewGameCommand { get; private set; }
        public DelegateCommand? LoadGameCommand { get; private set; }
        public DelegateCommand? SaveGameCommand { get; private set; }


        #endregion

        #region Events

        public event EventHandler? NewGame;

        public event EventHandler? LoadGame;
        
        public event EventHandler? SaveGame;

        #endregion

        public SquaresViewModel(SquaresGameModel model)
        {
            _model = model;
            _model.LineFilled += new EventHandler<SquaresLineEventArgs>(Game_LineFilled);
            _model.NextTurn += new EventHandler<SquaresGameEventArgs>(Game_NextTurn);
            _model.SquareFilled += new EventHandler<SquaresSquareEventArgs>(Game_SquareFilled);
            _model.LoadedTableSize += new EventHandler<SquaresGameEventArgs>(Game_LoadedTableSize);

            NewGameCommand = new DelegateCommand(param => OnNewGame());
            LoadGameCommand = new DelegateCommand(param => OnLoadGame());
            SaveGameCommand = new DelegateCommand(param => OnSaveGame());
            InitNewGame();
        }

        #region Public Methods
        public void InitNewGame()
        {
            InitNewGame(TableSize);
        }
        public void InitNewGame(int tableSize)
        {
            InitNewGame_SetFields(tableSize);

            _model.NewGame(TableSize);
        }
        #endregion

        #region Private methods

        private void FillLine(int x, int y, LineDirection direction)
        {
            _model.FillLine(x, y, direction);
        }
        private void InitNewGame_SetFields(int tableSize)
        {
            IsGameStarted = false;
            IsGameOver = false;
            TableSize = tableSize;
            if (GridPoints == null) GridPoints = new ObservableCollection<SquaresGridPoint>();
            GridPoints.Clear();
            for (int i = 0; i < TableSize; i++)
            {
                for (int j = 0; j < TableSize; j++)
                {
                    SquaresGridPoint newPoint = new SquaresGridPoint(j, i, TableSize);
                    newPoint.FillLineCommand = new DelegateCommand(param =>
                    {
                        if (param is Tuple<int, int, LineDirection> position)
                            FillLine(position.Item1, position.Item2, position.Item3);
                    });
                    GridPoints.Add(newPoint);

                }
            }
            NewGameTableSize = TableSize;
        }

        #endregion


        #region Game event handlers

        private void Game_LineFilled(object? sender, SquaresLineEventArgs e)
        {
            if (GridPoints == null) return;

            if (!IsGameStarted) IsGameStarted = true;

            if (e.Direction == LineDirection.Horizontal) GridPoints[e.X + _tableSize * e.Y].RightLineState = LineState.Filled;
            else if (e.Direction == LineDirection.Vertical) GridPoints[e.X + _tableSize * e.Y].BottomLineState = LineState.Filled;
        }
        private void Game_SquareFilled(object? sender, SquaresSquareEventArgs e)
        {
            if (GridPoints == null) return;
            GridPoints[e.X + _tableSize * e.Y].SquareState = e.Player;
        }
        private void Game_NextTurn(object? sender, SquaresGameEventArgs e)
        {
            CurrentPlayer = e.Player;
        }
        private void Game_LoadedTableSize(object? sender, SquaresGameEventArgs e)
        {
            InitNewGame_SetFields(e.AdditionalData);
        }

        #endregion


        #region Event methods
        private void OnNewGame()
        {
            NewGame?.Invoke(this, EventArgs.Empty);
        }
        private void OnLoadGame()
        {
            LoadGame?.Invoke(this, EventArgs.Empty);
        }

        private void OnSaveGame()
        {
            SaveGame?.Invoke(this, EventArgs.Empty);
        }
        #endregion
    }
}
