﻿using Squares.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace Squares.WPF.ViewModel
{
    public class SquaresGridPoint : ViewModelBase
    {
        #region Fields
        private int tableSize;
        private LineState bottomLineState;
        private LineState rightLineState;
        private PlayerId squareState;
        #endregion

        #region Properties

        // Point Data
        public int X { get; set; }
        public int Y { get; set; }
        public Tuple<int, int, LineDirection> BottomLineData
        {
            get { return new(X, Y, LineDirection.Vertical); }
        }
        public Tuple<int, int, LineDirection> RightLineData
        {
            get { return new(X, Y, LineDirection.Horizontal); }
        }
        public bool IsNotRightEdge { get { return X != tableSize - 1; } }
        public bool IsNotBottomEdge { get { return Y != tableSize - 1; } }

        // Lines, and States
        public LineState BottomLineState 
        { 
            get { return bottomLineState; }
            set
            {
                bottomLineState = value;
                OnPropertyChanged(nameof(BottomLineColor));
                OnPropertyChanged(nameof(IsBottomLineFilled));
            } 
        }
        public bool IsBottomLineFilled
        {
            get { return BottomLineState == LineState.Filled; }
        }
        public LineState RightLineState
        {
            get { return rightLineState; }
            set
            {
                rightLineState = value;
                OnPropertyChanged(nameof(RightLineColor));
                OnPropertyChanged(nameof(IsRightLineFilled));
            }
        }
        public bool IsRightLineFilled
        {
            get { return RightLineState == LineState.Filled; }
        }
        public SolidColorBrush BottomLineColor
        {
            get { return CalculateLineColor(BottomLineState); }
        }
        public SolidColorBrush RightLineColor
        {
            get { return CalculateLineColor(RightLineState); }
        }
        public PlayerId SquareState
        {
            get { return squareState; }
            set
            {
                squareState = value;
                OnPropertyChanged(nameof(SquareColor));
            }
        }
        public SolidColorBrush SquareColor
        {
            get
            {
                if (SquareState == PlayerId.Blue) return new SolidColorBrush(Color.FromRgb(15, 82, 186));
                else if (SquareState == PlayerId.Red) return new SolidColorBrush(Color.FromRgb(215, 0, 64));
                else return Brushes.Transparent;
            }
        }

        // Commands
        public DelegateCommand? FillLineCommand { get; set; }

        #endregion

        // Constructor
        public SquaresGridPoint(int x, int y, int tableSize)
        {
            BottomLineState = LineState.Empty;
            RightLineState = LineState.Empty;
            SquareState = PlayerId.Nobody;
            X = x;
            Y = y;
            this.tableSize = tableSize;
        }

        #region Private methods


        private SolidColorBrush CalculateLineColor(LineState state)
        {
            if (state == LineState.Empty)
            {
                return new SolidColorBrush(Color.FromRgb(200,200,200));
            }
            else if (state == LineState.Filled)
            {
                //if (SquareState == PlayerId.Blue) return new SolidColorBrush(Color.FromRgb(0, 50, 120));
                //else if (SquareState == PlayerId.Red) return new SolidColorBrush(Color.FromRgb(150, 0, 20));

                return new SolidColorBrush(Color.FromRgb(0, 0, 0));
            }
            return Brushes.Transparent;
        }

        #endregion

    }
}
