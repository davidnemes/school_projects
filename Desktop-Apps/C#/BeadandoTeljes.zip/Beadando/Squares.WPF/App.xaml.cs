﻿using System.Configuration;
using System.Data;
using System.Windows;
using Squares.Model;
using Squares.Persistence; 
using Squares.WPF.ViewModel;
using Squares.WPF.View;
using Microsoft.Win32;

namespace Squares.WPF
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private SquaresGameModel _model = null!;
        private SquaresViewModel _viewModel = null!;
        private MainWindow _view = null!;

        public App()
        {
            Startup += new StartupEventHandler(App_Startup);
        }

        #region Application event handlers
        private void App_Startup(object sender, StartupEventArgs e)
        {
            // modell létrehozása
            _model = new SquaresGameModel(new SquaresFileDataAccess());
            _model.GameOver += new EventHandler<SquaresGameEventArgs>(Model_GameOver);

            // nézemodell létrehozása
            _viewModel = new SquaresViewModel(_model);
            _viewModel.NewGame += new EventHandler(ViewModel_NewGame);
            _viewModel.LoadGame += new EventHandler(ViewModel_LoadGameAsync);
            _viewModel.SaveGame += new EventHandler(ViewModel_SaveGameAsync);

            // nézet létrehozása
            _view = new MainWindow();
            _view.DataContext = _viewModel;
            //_view.Closing += new System.ComponentModel.CancelEventHandler(View_Closing); // eseménykezelés a bezáráshoz
            _view.Show();
        }
        #endregion

        #region ViewModel event handlers
        private void ViewModel_NewGame(object? sender, EventArgs e)
        {
            if (_viewModel.IsGameStarted && !_viewModel.IsGameOver)
            {

                MessageBoxResult res = MessageBox.Show(
                    "A jelenlegi játékállás törlődni fog. Biztosan új játékot akarsz kezdeni?",
                    "Figyelem!",
                    MessageBoxButton.YesNo,
                    MessageBoxImage.Warning);
                if (res == MessageBoxResult.No) return;
            }
            _viewModel.InitNewGame(_viewModel.NewGameTableSize);
        }
        private async void ViewModel_LoadGameAsync(object? sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog(); // dialógusablak

            openFileDialog.Title = "Squares tábla betöltése";
            openFileDialog.Filter = "Text file (*.txt)|*.txt";
            if (openFileDialog.ShowDialog() == true) // ha kiválasztottunk egy fájlt
            {
                try
                {
                    await _model.LoadTableAsync(openFileDialog.FileName);
                }
                catch (SquaresDataException err)
                {
                    MessageBox.Show("Játék betöltése sikertelen!", "Hiba!", MessageBoxButton.OK, MessageBoxImage.Error);

                    _viewModel.InitNewGame();
                }
            }
        }
        private async void ViewModel_SaveGameAsync(object? sender, EventArgs e)
        {
            if (!_viewModel.IsGameStarted)
            {
                MessageBox.Show("Csak elkezdett játékot tudsz menteni!", "Infó", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (_viewModel.IsGameOver)
            {
                MessageBox.Show("Lezárt játékot nem tudsz menteni!", "Infó", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Title = "Squares játék mentése";
            saveFileDialog.Filter = "Text file (*.txt)|*.txt";
            if (saveFileDialog.ShowDialog() == true) // ha kiválasztottunk egy fájlt
            {
                try
                {
                    await _model.SaveTableAsync(saveFileDialog.FileName);
                }
                catch (SquaresDataException err)
                {
                    MessageBox.Show("Játék mentése sikertelen!", "Hiba!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        #endregion

        #region Model event handlers

        private void Model_GameOver(object? sender, SquaresGameEventArgs e)
        {
            _viewModel.IsGameOver = e.IsGameOver;
            string winner = e.Player == PlayerId.Nobody ? "Döntetlen" : e.Player == PlayerId.Blue ? "Nyertes: Kék" : "Nyertes: Piros";
            MessageBox.Show($"{winner}!", "Játék vége!", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        #endregion

    }

}
