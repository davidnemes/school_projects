﻿using Avalonia.Controls;

namespace Squares.Avalonia.Views;

public partial class MainView : UserControl
{
    public MainView()
    {
        InitializeComponent();
    }
}
