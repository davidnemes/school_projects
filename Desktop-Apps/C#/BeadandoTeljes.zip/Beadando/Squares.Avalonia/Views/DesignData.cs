﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Squares.Avalonia.ViewModels;
using Squares.Model;
using Squares.Persistence;

namespace Squares.Avalonia.Views
{
    public static class DesignData
    {
        public static SquaresViewModel ViewModel
        {
            get
            {
                var model = new SquaresGameModel(new SquaresFileDataAccess());
                // egy elindított játékot rakunk be a nézetmodellbe, így a tervezőfelületen sem csak üres cellák lesznek
                return new SquaresViewModel(model);
            }
        }
    }
}
