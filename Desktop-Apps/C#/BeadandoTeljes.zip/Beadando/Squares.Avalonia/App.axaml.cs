﻿using Avalonia;
using Avalonia.Controls;
using Avalonia.Controls.ApplicationLifetimes;
using Avalonia.Data.Core.Plugins;
using Avalonia.Markup.Xaml;
using Avalonia.Platform.Storage;
using Avalonia.Platform;
using Squares.Avalonia.ViewModels;
using Squares.Avalonia.Views;
using Squares.Model;
using Squares.Persistence;
using System;
using MsBox.Avalonia;
using MsBox.Avalonia.Enums;
using System.IO;

namespace Squares.Avalonia;

public partial class App : Application
{
    #region Fields

    private SquaresGameModel _model = null!;
    private SquaresViewModel _viewModel = null!;

    #endregion

    #region Properites

    private TopLevel? TopLevel
    {
        get
        {
            return ApplicationLifetime switch
            {
                IClassicDesktopStyleApplicationLifetime desktop => TopLevel.GetTopLevel(desktop.MainWindow),
                ISingleViewApplicationLifetime singleViewPlatform => TopLevel.GetTopLevel(singleViewPlatform.MainView),
                _ => null
            };
        }
    }

    #endregion

    #region Application methods

    public override void Initialize()
    {
        AvaloniaXamlLoader.Load(this);
    }

    public override void OnFrameworkInitializationCompleted()
    {
        // Without this line you will get duplicate validations from both Avalonia and CT
        BindingPlugins.DataValidators.RemoveAt(0);


        // modell létrehozása
        _model = new SquaresGameModel(new SquaresFileDataAccess());
        _model.GameOver += new EventHandler<SquaresGameEventArgs>(Model_GameOver);

        // nézemodell létrehozása
        _viewModel = new SquaresViewModel(_model);
        _viewModel.NewGame += new EventHandler(ViewModel_NewGame);
        _viewModel.LoadGame += new EventHandler(ViewModel_LoadGameAsync);
        _viewModel.SaveGame += new EventHandler(ViewModel_SaveGameAsync);

        if (ApplicationLifetime is IClassicDesktopStyleApplicationLifetime desktop)
        {
            desktop.MainWindow = new MainWindow
            {
                DataContext = _viewModel
            };

            desktop.Startup += async (s, e) =>
            {
                // betöltjük a felfüggesztett játékot, amennyiben van
                try
                {
                    await _model.LoadTableAsync(
                        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "SquaresSuspendedGame"));
                }
                catch { }
            };

            desktop.Exit += async (s, e) =>
            {
                // elmentjük a jelenleg folyó játékot
                try
                {
                    await _model.SaveTableAsync(
                        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "SquaresSuspendedGame"));
                    // mentés a felhasználó Documents könyvtárába, oda minden bizonnyal van jogunk írni
                }
                catch { }
            };
        }
        else if (ApplicationLifetime is ISingleViewApplicationLifetime singleViewPlatform)
        {
            singleViewPlatform.MainView = new MainView
            {
                DataContext = _viewModel
            };

            if (Application.Current?.TryGetFeature<IActivatableLifetime>() is { } activatableLifetime)
            {
                activatableLifetime.Activated += async (sender, args) =>
                {
                    if (args.Kind == ActivationKind.Background)
                    {
                        // betöltjük a felfüggesztett játékot, amennyiben van
                        try
                        {
                            await _model.LoadTableAsync(
                                Path.Combine(AppContext.BaseDirectory, "SuspendedGame"));
                        }
                        catch
                        {
                        }
                    }
                };
                activatableLifetime.Deactivated += async (sender, args) =>
                {
                    if (args.Kind == ActivationKind.Background)
                    {

                        // elmentjük a jelenleg folyó játékot
                        try
                        {
                            await _model.SaveTableAsync(
                                Path.Combine(AppContext.BaseDirectory, "SuspendedGame"));
                            // Androidon az AppContext.BaseDirectory az alkalmazás adat könyvtára, ahova
                            // akár külön jogosultság nélkül is lehetne írni
                        }
                        catch
                        {
                        }
                    }
                };
            }
        }

        base.OnFrameworkInitializationCompleted();
    }
    #endregion


    #region ViewModel event handlers
    private async void ViewModel_NewGame(object? sender, EventArgs e)
    {
        if (_viewModel.IsGameStarted && !_viewModel.IsGameOver)
        {

            ButtonResult res = await MessageBoxManager.GetMessageBoxStandard(
                "Figyelem!",
                "A jelenlegi játékállás törlődni fog. Biztosan új játékot akarsz kezdeni?",
                ButtonEnum.YesNo,
                Icon.Warning).ShowAsync();
            if (res == ButtonResult.No) return;
        }
        _viewModel.InitNewGame(_viewModel.NewGameTableSize);
    }
    private async void ViewModel_LoadGameAsync(object? sender, EventArgs e)
    {
        if (TopLevel == null)
        {
            await MessageBoxManager.GetMessageBoxStandard(
                    "Squares",
                    "A fájlkezelés nem támogatott!",
                    ButtonEnum.Ok, Icon.Error)
                .ShowAsync();
            return;
        }

        try
        {
            var files = await TopLevel.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
            {
                Title = "Squares tábla betöltése",
                AllowMultiple = false,
                FileTypeFilter = new[]
                {
                    new FilePickerFileType("Squares Tábla")
                    {
                        Patterns = new[] { "*.txt" }
                    }
                }
            });

            if (files.Count > 0)
            {
                // játék betöltése
                using (var stream = await files[0].OpenReadAsync())
                {
                    await _model.LoadTableAsync(stream);
                }
            }
        }
        catch (SquaresDataException)
        {
            await MessageBoxManager.GetMessageBoxStandard(
                    "Squares",
                    "A fájl betöltése sikertelen!",
                    ButtonEnum.Ok, Icon.Error)
                .ShowAsync();
        }
    }
    private async void ViewModel_SaveGameAsync(object? sender, EventArgs e)
    {
        if (TopLevel == null)
        {
            await MessageBoxManager.GetMessageBoxStandard(
                    "Squares",
                    "A fájlkezelés nem támogatott!",
                    ButtonEnum.Ok, Icon.Error)
                .ShowAsync();
            return;
        }

        if (!_viewModel.IsGameStarted)
        {
            await MessageBoxManager.GetMessageBoxStandard(
                    "Infó",
                    "Csak elkezdett játékot tudsz menteni!",
                    ButtonEnum.Ok, Icon.Info)
                .ShowAsync();
            return;
        }
        if (_viewModel.IsGameOver)
        {
            await MessageBoxManager.GetMessageBoxStandard(
                    "Infó",
                    "Lezárt játékot nem tudsz menteni!",
                    ButtonEnum.Ok, Icon.Info)
                .ShowAsync();
            return;
        }

        try
        {
            var file = await TopLevel.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions()
            {
                Title = "Squares tábla mentése",
                FileTypeChoices = new[]
                {
                    new FilePickerFileType("Squares tábla")
                    {
                        Patterns = new[] { "*.txt" }
                    }
                }
            });

            if (file != null)
            {
                // játék mentése
                using (var stream = await file.OpenWriteAsync())
                {
                    await _model.SaveTableAsync(stream);
                }
            }
        }
        catch (Exception ex)
        {
            await MessageBoxManager.GetMessageBoxStandard(
                    "Sqaures",
                    "A fájl mentése sikertelen!" + ex.Message,
                    ButtonEnum.Ok, Icon.Error)
                .ShowAsync();
        }
    }

    #endregion

    #region Model event handlers

    private async void Model_GameOver(object? sender, SquaresGameEventArgs e)
    {
        _viewModel.IsGameOver = e.IsGameOver;
        string winner = e.Player == PlayerId.Nobody ? "Döntetlen" : e.Player == PlayerId.Blue ? "Nyertes: Kék" : "Nyertes: Piros";
        await MessageBoxManager.GetMessageBoxStandard("Játék vége!", $"{winner}!", ButtonEnum.Ok, Icon.Info).ShowAsync();
    }

    #endregion
}
