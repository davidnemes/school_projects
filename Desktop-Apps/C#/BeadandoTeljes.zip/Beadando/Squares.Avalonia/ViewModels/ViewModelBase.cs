﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace Squares.Avalonia.ViewModels;

public class ViewModelBase : ObservableObject
{
}
