using Squares.Model;
using Squares.Persistence;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Security.Policy;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Menu;

namespace Squares.WinForms
{
    // Struct Grid Point-hoz �s T�bla m�retekhez
    public struct GridPoint
    {
        public Panel bottom;
        public Panel right;
    }
    public struct TableSize
    {
        public int lineLength;
        public int circleSize;
    }

    public partial class SquaresWinForm : Form
    {
        // Grid Param�terek
        private int tableSize = 9;             // lehet 3, 5 vagy 9
        private readonly int tableMargin = 75; // ez fix
        private readonly int lineWidth = 15;   // ez fix
        private int lineLength;                // NewGame �ll�tja be 
        private int circleSize;                // NewGame �ll�tja be
        private readonly Dictionary<int, TableSize> tableSizes = new Dictionary<int, TableSize>
        {
            { 3, new TableSize { lineLength = 300, circleSize = 50 } },
            { 5, new TableSize { lineLength = 150, circleSize = 50 } },
            { 9, new TableSize { lineLength = 75, circleSize = 30 } }
        };
        private Image circleImage; // GenerateGrid �ll�tja be


        // Grid Kont�nerek
        private GridPoint[,] gridPoints;
        private PlayerId[,] squaresState;

        // Tov�bbi, a j�t�khoz sz�ks�ges field-ek
        private PlayerId currentPlayer; // Current Player, lehet Blue vagy Red
        private bool isGameOver;
        private bool isGameStarted;
        private int newGameSize;

        // Model
        private SquaresGameModel _model;


        /*
         * Constructor
         *  */

        public SquaresWinForm()
        {
            InitializeComponent();

            // model l�trehoz�s, esem�nykezel�k
            ISquaresDataAccess dataAccess = new SquaresFileDataAccess();
            _model = new SquaresGameModel(dataAccess);
            _model.LineFilled += new EventHandler<SquaresLineEventArgs>(Game_LineFilled);
            _model.SquareFilled += new EventHandler<SquaresSquareEventArgs>(Game_SquareFilled);
            _model.NextTurn += new EventHandler<SquaresGameEventArgs>(Game_NextTurn);
            _model.GameOver += new EventHandler<SquaresGameEventArgs>(Game_GameOver);
            _model.LoadedTableSize += new EventHandler<SquaresGameEventArgs>(Game_LoadedTableSize);


            // �j j�t�k l�trehoz�sa
            NewGame(tableSize);

            // Gridet kirajzol� eventlistener
            this.Paint += new PaintEventHandler(Grid_Paint);

            // Gridm�ret �ll�t�s�n�l ne z�r�djon be a dropdown
            menuGame.DropDown.Closing += new ToolStripDropDownClosingEventHandler(DropDown_Closing);

            // Ablakm�ret Be�ll�t�sa
            this.ClientSize = new Size(765, 765);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;  // Fix�lt ablakkeret
            this.MaximizeBox = false;
            this.DoubleBuffered = true;
        }

        /*
         * Private game methods
         * */

        private void NewGame(int size)
        {
            // Model utas�t�sa �j j�t�k kezd�s�re
            _model.NewGame(size);

            NewGame_SetFields(size);
        }
        private void NewGame_SetFields(int size)
        {
            // Field-ek be�ll�t�sa
            tableSize = size;
            isGameStarted = false;
            isGameOver = false;
            lineLength = tableSizes[tableSize].lineLength;
            circleSize = tableSizes[tableSize].circleSize;

            // j�t�kt�bla �s men�k inicializ�l�sa
            gridPoints = new GridPoint[tableSize, tableSize];
            squaresState = new PlayerId[tableSize - 1, tableSize - 1];
            for (int i = 0; i < tableSize - 1; i++)
                for (int j = 0; j < tableSize - 1; j++)
                    squaresState[i, j] = PlayerId.Nobody;
            GenerateGrid();
        }

        private void GenerateGrid()
        {
            // Image F�jl bet�lt�se
            try
            {
                circleImage = Image.FromFile("C:\\Users\\nemes\\SULI\\eva\\beadando1\\Squares\\Squares\\Assets\\point.png");
            }
            catch (Exception ex)
            {
                MessageBox.Show("A Pont k�p bet�lt�se sikertelen: " + ex.Message);
            }

            // Kor�bbi panelek, pictureBox-ok t�rl�se
            for (int i = Controls.Count - 1; i >= 0; i--)
            {
                if (Controls[i] is Panel || Controls[i] is PictureBox) Controls.RemoveAt(i);
            }

            int size = tableSize;
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    int posX = i * lineLength + tableMargin;
                    int posY = j * lineLength + tableMargin;
                    
                    newCircle(new Point(posX, posY), new Size(circleSize, circleSize));
                    if (i < size-1) gridPoints[i, j].right = newLine(new Point(posX, posY), new Size(lineLength, lineWidth), new Point(i, j));
                    if (j < size-1) gridPoints[i, j].bottom = newLine(new Point(posX, posY), new Size(lineWidth, lineLength), new Point(i, j));
                }
            }
        }

        private Panel newLine(Point pos, Size size, Point index)
        {
            Panel line = new Panel();

            line.Location = pos;
            line.Size = size;
            line.BackColor = Color.FromArgb(200, 200, 200);
            line.Cursor = Cursors.Hand;
            line.Tag = index;

            line.Click += Line_Click;

            line.MouseEnter += Line_MouseEnter;
            line.MouseLeave += Line_MouseLeave;

            Controls.Add(line);
            Controls.SetChildIndex(line, 2);
            return line;
        }

        private void newCircle(Point pos, Size size)
        {
            PictureBox circlePic = new PictureBox();
            circlePic.Image = circleImage;
            
            int _size = size.Width;
            pos.X += lineWidth / 2 - _size / 2 + 2;
            pos.Y += lineWidth / 2 - _size / 2 + 2;
            circlePic.Size = size;
            circlePic.Location = pos;
            circlePic.BackColor = Color.Transparent;
            circlePic.SizeMode = PictureBoxSizeMode.StretchImage;

            Controls.Add(circlePic);
            Controls.SetChildIndex(circlePic, 1);
        }

        private void SetMenuGameSizeChecked(int size)
        {
            switch(size)
            {
                case 3:
                    menuGame3x3.Checked = true;
                    menuGame5x5.Checked = false;
                    menuGame9x9.Checked = false;
                    break;
                case 5:
                    menuGame3x3.Checked = false;
                    menuGame5x5.Checked = true;
                    menuGame9x9.Checked = false;
                    break;
                case 9:
                    menuGame3x3.Checked = false;
                    menuGame5x5.Checked = false;
                    menuGame9x9.Checked = true;
                    break;
                default:
                    menuGame3x3.Checked = false;
                    menuGame5x5.Checked = false;
                    menuGame9x9.Checked = false;
                    break;
            }
        }

        /*
         * Esem�nykezel�k a gridhez
         * */

        private void Line_Click(object? sender, EventArgs e)
        {
            Panel? line = sender as Panel;

            if (line != null)
            {
                Point tag = (Point)line.Tag;
                LineDirection direction = line.Width > line.Height ? LineDirection.Horizontal : LineDirection.Vertical;
                _model.FillLine(tag.X, tag.Y, direction);
            }
        }

        private void Line_MouseEnter(object? sender, EventArgs e)
        {
            Panel? hoveredLine = sender as Panel;
            if (hoveredLine != null && hoveredLine.BackColor == Color.FromArgb(200, 200, 200))
            {
                hoveredLine.BackColor = Color.FromArgb(100, 100, 100); // Sz�nv�ltoztat�s
            }
        }
        private void Line_MouseLeave(object? sender, EventArgs e)
        {
            Panel? hoveredLine = sender as Panel;
            if (hoveredLine != null && hoveredLine.BackColor == Color.FromArgb(100, 100, 100))
            {
                hoveredLine.BackColor = Color.FromArgb(200, 200, 200); // Eredeti sz�n vissza�ll�t�sa
            }
        }

        /*
         * Esem�nykezel�k a men�h�z
         * */
        private void MenuGame_Click(object? sender, EventArgs e)
        {
            SetMenuGameSizeChecked(tableSize);
        }
        private void MenuGameSize_Click(object? sender, EventArgs e)
        {

            ToolStripMenuItem clickedItem = sender as ToolStripMenuItem;
            if (clickedItem != null)
            {
                // Lek�rj�k a Name attrib�tumot
                string itemName = clickedItem.Name;

                newGameSize = itemName == "menuGame3x3" ? 3 : itemName == "menuGame5x5" ? 5 : itemName == "menuGame9x9" ? 9 : 0;
                SetMenuGameSizeChecked(newGameSize);
                menuGame.ShowDropDown();
            }
        }
        private void DropDown_Closing(object? sender, ToolStripDropDownClosingEventArgs e)
        {
            
            if (e.CloseReason == ToolStripDropDownCloseReason.ItemClicked)
            {
                e.Cancel = true;
            }
        }
        private void MenuGameNewGame_Click(object? sender, EventArgs e)
        {
            try
            {
                if (newGameSize == 0) newGameSize = tableSize;

                if (isGameStarted && !isGameOver)
                {
                    DialogResult res = MessageBox.Show(
                        "A jelenlegi j�t�k�ll�s t�rl�dni fog. Biztosan �j j�t�kot akarsz kezdeni?", 
                        "Figyelem!", 
                        MessageBoxButtons.YesNo,
                        MessageBoxIcon.Warning);
                    if (res == DialogResult.No) return;
                }

                NewGame(newGameSize);
            } finally
            {
                menuGame.DropDown.Close();
            }
        }
        private async void MenuLoadGame_Click(object? sender, EventArgs e)
        {
            if (_openFileDialog.ShowDialog() == DialogResult.OK) // ha kiv�lasztottunk egy f�jlt
            {
                try
                {
                    await _model.LoadTableAsync(_openFileDialog.FileName);
                }
                catch (SquaresDataException err)
                {
                    MessageBox.Show("J�t�k bet�lt�se sikertelen!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    NewGame(tableSize);
                }
            }
        }
        private async void MenuSaveGame_Click(object? sender, EventArgs e)
        {
            if (!isGameStarted)
            {
                MessageBox.Show("Csak elkezdett j�t�kot tudsz menteni!", "Inf�", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (isGameOver)
            {
                MessageBox.Show("Lez�rt j�t�kot nem tudsz menteni!", "Inf�", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            if (_saveFileDialog.ShowDialog() == DialogResult.OK) // ha kiv�lasztottunk egy f�jlt
            {
                try
                {
                    await _model.SaveTableAsync(_saveFileDialog.FileName);
                }
                catch (SquaresDataException err)
                {
                    MessageBox.Show("J�t�k ment�se sikertelen!", "Hiba!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        /*
         * Paint event handlers
         * */

        private void Grid_Paint(object? sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;

            // Sim�bb k�rvonal�rt
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            if (currentPlayer == PlayerId.Blue) this.BackColor = Color.FromArgb(191, 223, 255);
            else if (currentPlayer == PlayerId.Red) this.BackColor = Color.FromArgb(250, 160, 160);

            using SolidBrush firstPlayer = new SolidBrush(Color.FromArgb(15, 82, 186));
            using SolidBrush secondPlayer = new SolidBrush(Color.FromArgb(215, 0, 64));

            int rectSize = lineLength + lineWidth;
            for (int i = 0; i < squaresState.GetLength(0); i++)
            {
                for (int j = 0; j < squaresState.GetLength(1); j++)
                {
                    if (squaresState[i, j] == PlayerId.Nobody) continue;
                    int posX = i * lineLength + tableMargin;
                    int posY = j * lineLength + tableMargin;

                    switch (squaresState[i,j])
                    {
                        case PlayerId.Blue:
                            g.FillRectangle(firstPlayer, posX, posY, rectSize, rectSize);
                            gridPoints[i, j].bottom.BackColor = Color.FromArgb(0, 50, 120);
                            gridPoints[i, j].right.BackColor = Color.FromArgb(0, 50, 120);
                            gridPoints[i+1, j].bottom.BackColor = Color.FromArgb(0, 50, 120);
                            gridPoints[i, j+1].right.BackColor = Color.FromArgb(0, 50, 120);
                            break;
                        case PlayerId.Red:
                            g.FillRectangle(secondPlayer, posX, posY, rectSize, rectSize);
                            gridPoints[i, j].bottom.BackColor = Color.FromArgb(150, 0, 20);
                            gridPoints[i, j].right.BackColor = Color.FromArgb(150, 0, 20);
                            gridPoints[i + 1, j].bottom.BackColor = Color.FromArgb(150, 0, 20);
                            gridPoints[i, j + 1].right.BackColor = Color.FromArgb(150, 0, 20);
                            break;
                    }
                }
            }
        }

        /*
         * Model event handlers
         * */
        private void Game_LineFilled(object? sender, SquaresLineEventArgs e)
        {
            if (!isGameStarted) isGameStarted = true;

            if (e.Direction == LineDirection.Horizontal) gridPoints[e.X, e.Y].right.BackColor = Color.Black;
            else if (e.Direction == LineDirection.Vertical) gridPoints[e.X, e.Y].bottom.BackColor = Color.Black;
        }

        private void Game_SquareFilled(object? sender, SquaresSquareEventArgs e)
        {
            squaresState[e.X, e.Y] = e.Player;
            Invalidate();
        }

        private void Game_NextTurn(object? sender, SquaresGameEventArgs e)
        {
            currentPlayer = e.Player;
            Invalidate();
        }

        private void Game_GameOver(object? sender, SquaresGameEventArgs e)
        {
            isGameOver = e.IsGameOver;
            string winner = e.Player == PlayerId.Nobody ? "D�ntetlen" : e.Player == PlayerId.Blue ? "Nyertes: K�k" : "Nyertes: Piros";
            MessageBox.Show($"{winner}!", "J�t�k v�ge!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void Game_LoadedTableSize(object? sender, SquaresGameEventArgs e)
        {
            NewGame_SetFields(e.AdditionalData);
        }

    }
}
