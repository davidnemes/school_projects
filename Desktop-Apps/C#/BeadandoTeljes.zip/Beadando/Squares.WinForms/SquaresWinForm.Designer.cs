﻿namespace Squares.WinForms
{
    partial class SquaresWinForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            _menuStrip = new MenuStrip();
            menuFile = new ToolStripMenuItem();
            menuFileLoadGame = new ToolStripMenuItem();
            menuFileSaveGame = new ToolStripMenuItem();
            menuGame = new ToolStripMenuItem();
            menuGame3x3 = new ToolStripMenuItem();
            menuGame5x5 = new ToolStripMenuItem();
            menuGame9x9 = new ToolStripMenuItem();
            toolStripSeparator1 = new ToolStripSeparator();
            menuGameNew = new ToolStripMenuItem();
            _openFileDialog = new OpenFileDialog();
            _saveFileDialog = new SaveFileDialog();
            _menuStrip.SuspendLayout();
            SuspendLayout();
            // 
            // _menuStrip
            // 
            _menuStrip.ImageScalingSize = new Size(20, 20);
            _menuStrip.Items.AddRange(new ToolStripItem[] { menuFile, menuGame });
            _menuStrip.Location = new Point(0, 0);
            _menuStrip.Name = "_menuStrip";
            _menuStrip.Size = new Size(711, 28);
            _menuStrip.TabIndex = 0;
            _menuStrip.Text = "_menuStrip";
            // 
            // menuFile
            // 
            menuFile.DropDownItems.AddRange(new ToolStripItem[] { menuFileLoadGame, menuFileSaveGame });
            menuFile.Name = "menuFile";
            menuFile.Size = new Size(46, 24);
            menuFile.Text = "File";
            // 
            // menuFileLoadGame
            // 
            menuFileLoadGame.Name = "menuFileLoadGame";
            menuFileLoadGame.Size = new Size(168, 26);
            menuFileLoadGame.Text = "Load Game";
            menuFileLoadGame.Click += MenuLoadGame_Click;
            // 
            // menuFileSaveGame
            // 
            menuFileSaveGame.Name = "menuFileSaveGame";
            menuFileSaveGame.Size = new Size(168, 26);
            menuFileSaveGame.Text = "Save Game";
            menuFileSaveGame.Click += MenuSaveGame_Click;
            // 
            // menuGame
            // 
            menuGame.DropDownItems.AddRange(new ToolStripItem[] { menuGame3x3, menuGame5x5, menuGame9x9, toolStripSeparator1, menuGameNew });
            menuGame.Name = "menuGame";
            menuGame.Size = new Size(62, 24);
            menuGame.Text = "Game";
            menuGame.Click += MenuGame_Click;
            // 
            // menuGame3x3
            // 
            menuGame3x3.Name = "menuGame3x3";
            menuGame3x3.Size = new Size(165, 26);
            menuGame3x3.Text = "3 x 3";
            menuGame3x3.Click += MenuGameSize_Click;
            // 
            // menuGame5x5
            // 
            menuGame5x5.Name = "menuGame5x5";
            menuGame5x5.Size = new Size(165, 26);
            menuGame5x5.Text = "5 x 5";
            menuGame5x5.Click += MenuGameSize_Click;
            // 
            // menuGame9x9
            // 
            menuGame9x9.Name = "menuGame9x9";
            menuGame9x9.Size = new Size(165, 26);
            menuGame9x9.Text = "9 x 9";
            menuGame9x9.Click += MenuGameSize_Click;
            // 
            // toolStripSeparator1
            // 
            toolStripSeparator1.Name = "toolStripSeparator1";
            toolStripSeparator1.Size = new Size(162, 6);
            // 
            // menuGameNew
            // 
            menuGameNew.Name = "menuGameNew";
            menuGameNew.Size = new Size(165, 26);
            menuGameNew.Text = "New Game";
            menuGameNew.Click += MenuGameNewGame_Click;
            // 
            // _openFileDialog
            // 
            _openFileDialog.FileName = "_openFileDialog";
            _openFileDialog.Filter = "Text file (*.txt)|*.txt";
            _openFileDialog.Title = "Squares játék betöltése";
            // 
            // _saveFileDialog
            // 
            _saveFileDialog.Filter = "Text file (*.txt)|*.txt";
            _saveFileDialog.Title = "Squares játék mentése";
            // 
            // SquaresWinForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(711, 429);
            Controls.Add(_menuStrip);
            MainMenuStrip = _menuStrip;
            Name = "SquaresWinForm";
            Text = "Squares";
            Paint += Grid_Paint;
            _menuStrip.ResumeLayout(false);
            _menuStrip.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip _menuStrip;
        private ToolStripMenuItem menuFile;
        private ToolStripMenuItem menuFileLoadGame;
        private ToolStripMenuItem menuFileSaveGame;
        private ToolStripMenuItem menuGame;
        private ToolStripMenuItem menuGame3x3;
        private ToolStripMenuItem menuGame5x5;
        private ToolStripMenuItem menuGame9x9;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem menuGameNew;
        private OpenFileDialog _openFileDialog;
        private SaveFileDialog _saveFileDialog;
    }
}
