﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Squares.Model
{
    public enum PlayerId
    {
        Nobody,
        Blue,
        Red,
    }

    public struct LoadEvent
    {
        public string action;
        public int x;
        public int y;
        public PlayerId player;
        public LoadEvent(string action, int x, int y, PlayerId player = PlayerId.Nobody)
        {
            this.action = action;
            this.x = x;
            this.y = y;
            this.player = player;
        }
    }

    public class SquaresTable
    {
        private int size;
        private SquaresPoint[,] points;
                                           // squaresState length is points.Length -1
        private PlayerId[,] squaresState;  // Nobody => not locked, Blue => player1 locked, Red => player2 locked
        private PlayerId currentPlayer;    // Blue or Red

        // A Játék fájlból való betöltéséhez szükséges
        public List<LoadEvent>? loadEvents;

        public int Size { get { return size; } }
        public PlayerId CurrentPlayer { get { return currentPlayer; } }

        public SquaresTable() : this(3) { }

        /*
         * Constructors
         * */

        public SquaresTable(int capacity)
        {
            size = capacity;
            points = new SquaresPoint[size, size];
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    points[i, j] = new SquaresPoint(i, j);
                }
            }

            squaresState = new PlayerId[size - 1, size - 1];
            for (int i = 0; i < size -1; i++)
            {
                for (int j = 0; j < size -1; j++)
                {
                    squaresState[i, j] = PlayerId.Nobody;
                }
            }
            NextTurn();
        }

        /*
         * Public methods
         * */

        public PlayerId NextTurn()
        {
            if (currentPlayer == PlayerId.Nobody) currentPlayer = PlayerId.Blue;
            else currentPlayer = currentPlayer == PlayerId.Blue ? PlayerId.Red : PlayerId.Blue;

            return currentPlayer;
        }

        public bool FillLine(int x, int y, LineDirection direction)
        {
            if (x == size - 1 && direction == LineDirection.Horizontal) throw new InvalidOperationException("Out of table!");
            if (y == size - 1 && direction == LineDirection.Vertical) throw new InvalidOperationException("Out of table!");

            return points[x, y].lineFilled(direction);
        }

        public List<(int, int, PlayerId)> CheckSquares(int x, int y, LineDirection direction)
        {
            var ret = new List<(int, int, PlayerId)>();

            int sqX = x, sqY = y;

            if (CheckSquareLock(sqX, sqY)) ret.Add((sqX, sqY, currentPlayer));

            if (direction == LineDirection.Horizontal) sqY--;
            else if (direction == LineDirection.Vertical) sqX--;
            if (CheckSquareLock(sqX, sqY)) ret.Add((sqX, sqY, currentPlayer));

            return ret;
        }

        public (bool, PlayerId) IsGameOver()
        {
            bool allSquaresLocked = true;
            int firstPlayerPoints = 0;
            int secondPlayerPoints = 0;

            for (int i = 0; i < squaresState.GetLength(0); i++)
            {
                for (int j = 0; j < squaresState.GetLength(1); j++)
                {
                    if (squaresState[i, j] == 0)
                    {
                        allSquaresLocked = false; 
                        break;
                    } else
                    {
                        if (squaresState[i, j] == PlayerId.Blue) firstPlayerPoints++;
                        else if (squaresState[i, j] == PlayerId.Red) secondPlayerPoints++;
                    }
                }
                if (!allSquaresLocked) break;
            }

            PlayerId winner = PlayerId.Nobody;
            if (allSquaresLocked && firstPlayerPoints != secondPlayerPoints)
                winner = firstPlayerPoints > secondPlayerPoints ? PlayerId.Blue : PlayerId.Red;
            return (allSquaresLocked, winner);
        }

        // Method a Fájlból betöltéshez, és Teszteléshez
        public void AlterTable(string action, int x, int y, PlayerId player = PlayerId.Nobody)
        {
            switch(action)
            {
                case "fillRightLine":
                    FillLine(x, y, LineDirection.Horizontal);
                    break;
                case "fillBottomLine":
                    FillLine(x, y, LineDirection.Vertical);
                    break;
                case "fillSquareBlue":
                    squaresState[x, y] = PlayerId.Blue;
                    break;
                case "fillSquareRed":
                    squaresState[x, y] = PlayerId.Red;
                    break;
                case "playerTurns":
                    currentPlayer = player;
                    break;
            }
            LoadEvent _event = new LoadEvent(action, x, y, player);
            if (loadEvents == null) loadEvents = new List<LoadEvent>(); // ha még nincs lista, létrehozzuk
            loadEvents.Add(_event);
        }
        // Method a Fájlba mentéshez, teszteléshez
        public (SquaresPoint[,], PlayerId[,]) DumpTable()
        {
            SquaresPoint[,] retPoints = new SquaresPoint[size, size];
            for (int i = 0; i < size; i++)
            {
                for (int j = 0; j < size; j++)
                {
                    SquaresPoint point = points[i, j];
                    retPoints[i, j] = new SquaresPoint(point.positionX, point.positionY);
                    if (point.BottomLine.State == LineState.Filled) retPoints[i,j].lineFilled(LineDirection.Vertical);
                    if (point.RightLine.State == LineState.Filled) retPoints[i,j].lineFilled(LineDirection.Horizontal);
                }
            }

            PlayerId[,] retSquaresState = new PlayerId[size - 1, size - 1];
            for (int i = 0; i < size-1; i++)
            {
                for (int j = 0; j < size-1; j++)
                {
                    retSquaresState[i, j] = squaresState[i, j];
                }
            }
            return (retPoints, retSquaresState);
        }


        /*
         * Private Methods
         * */

        private bool CheckSquareLock(int sqX, int sqY)
        {
            if (sqX < 0 || sqX >= squaresState.GetLength(0)) return false;
            if (sqY < 0 || sqY >= squaresState.GetLength(1)) return false;
            if (squaresState[sqX, sqY] != 0) return false;

            bool allFilled = true;

            SquaresLine top = points[sqX, sqY].RightLine;
            SquaresLine right = points[sqX + 1, sqY].BottomLine;
            SquaresLine bottom = points[sqX, sqY + 1].RightLine;
            SquaresLine left = points[sqX, sqY].BottomLine;
            SquaresLine[] lines = { top, right, bottom, left };
            foreach (var line in lines)
            {
                if (line.State == LineState.Empty)
                {
                    allFilled = false;
                    break;
                }
            }

            if (allFilled) squaresState[sqX, sqY] = currentPlayer;
            return allFilled;
        }

    }
}
