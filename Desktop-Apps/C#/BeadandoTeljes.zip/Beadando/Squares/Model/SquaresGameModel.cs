﻿using Squares.Persistence;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Collections.Specialized.BitVector32;

namespace Squares.Model
{
    public class SquaresGameModel
    {
        private ISquaresDataAccess _dataAccess;
        private SquaresTable _table;

        // Events
        public event EventHandler<SquaresLineEventArgs>? LineFilled;
        public event EventHandler<SquaresSquareEventArgs>? SquareFilled;
        public event EventHandler<SquaresGameEventArgs>? GameOver;
        public event EventHandler<SquaresGameEventArgs>? NextTurn;
        public event EventHandler<SquaresGameEventArgs>? LoadedTableSize;

        // Contructor
        public SquaresGameModel(ISquaresDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
            _table = new SquaresTable();
        }

        /*
         * Public methods
         * */
        public void NewGame(int n)
        {
            _table = new SquaresTable(n);
            OnNextTurn(PlayerId.Blue);
        }

        public void FillLine(int pointX, int pointY, LineDirection direction)
        {
            bool filled = _table.FillLine(pointX, pointY, direction);
            if (filled)
            {
                OnLineFilled(pointX, pointY, direction);
                List<(int, int, PlayerId)> filledSquares = _table.CheckSquares(pointX, pointY, direction);
                if (filledSquares.Count > 0)
                {
                    foreach ((int x, int y, PlayerId player) in filledSquares) OnSquareFilled(x, y, player);

                    bool gameOver; PlayerId winner;
                    (gameOver, winner) = _table.IsGameOver();
                    if (gameOver) OnGameOver(gameOver, winner);
                }
                else
                {
                    OnNextTurn(_table.NextTurn());
                }
            }
        }

        public async Task LoadTableAsync(string path)
        {
            await LoadTableAsync(File.OpenRead(path));
        }
        public async Task LoadTableAsync(Stream stream)
        {
            if (_dataAccess == null) throw new InvalidOperationException("No data access is provided.");

            _table = await _dataAccess.LoadAsync(stream);
            RunTableEventsAfterLoad();
        }

        public async Task SaveTableAsync(string path)
        {
            await SaveTableAsync(File.OpenWrite(path));
        }
        public async Task SaveTableAsync(Stream stream)
        {
            if (_dataAccess == null) throw new InvalidOperationException("No data access is provided.");

            await _dataAccess.SaveAsync(stream, _table);
        }

        /*
         * Private methods
         * */
        private void RunTableEventsAfterLoad()
        {
            if (_table.loadEvents == null) return;
            for (int i = 0; i < _table.loadEvents.Count; i++)
            {
                LoadEvent ev = _table.loadEvents[i];
                switch (ev.action)
                {
                    case "fillRightLine":
                        OnLineFilled(ev.x, ev.y, LineDirection.Horizontal);
                        break;
                    case "fillBottomLine":
                        OnLineFilled(ev.x, ev.y, LineDirection.Vertical);
                        break;
                    case "fillSquareBlue":
                        OnSquareFilled(ev.x, ev.y, PlayerId.Blue);
                        break;
                    case "fillSquareRed":
                        OnSquareFilled(ev.x, ev.y, PlayerId.Red);
                        break;
                    case "loadedTableSize":
                        OnLoadedTableSize(ev.x);
                        break;
                    case "playerTurns":
                        OnNextTurn(ev.player);
                        break;
                }
            }
            _table.loadEvents.Clear();
        }


        /*
         * Private event methods
         * */
        private void OnLineFilled(int x, int y, LineDirection direction)
        {
            LineFilled?.Invoke(this, new SquaresLineEventArgs(x, y, direction));
        }
        private void OnSquareFilled(int x, int y, PlayerId player)
        {
            SquareFilled?.Invoke(this, new SquaresSquareEventArgs(x, y, player));
        }
        private void OnGameOver(bool isGameOver, PlayerId winner)
        {
            GameOver?.Invoke(this, new SquaresGameEventArgs(isGameOver, winner));
        }
        private void OnNextTurn(PlayerId playerTurns)
        {
            NextTurn?.Invoke(this, new SquaresGameEventArgs(false, playerTurns));
        }
        private void OnLoadedTableSize(int size)
        {
            LoadedTableSize?.Invoke(this, new SquaresGameEventArgs(false, PlayerId.Nobody, size)); // felhasználom ezt az EventArgs-ot erre a célra is
        }

    }
}
