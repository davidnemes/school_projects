﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Squares.Model
{
    public class SquaresPoint
    {
        private SquaresLine bottomLine;
        private SquaresLine rightLine;
        public int positionX;
        public int positionY;

        public SquaresLine BottomLine { get { return bottomLine; } }
        public SquaresLine RightLine { get { return rightLine; } }

        public SquaresPoint(int positionX, int positionY)
        {
            bottomLine = new SquaresLine(this, LineDirection.Vertical);
            rightLine = new SquaresLine(this, LineDirection.Horizontal);
            this.positionX = positionX;
            this.positionY = positionY;
        }

        public bool lineFilled(LineDirection direction)
        {
            if (direction == LineDirection.Horizontal)
            {
                if (rightLine.State == LineState.Filled) return false;
                rightLine.State = LineState.Filled;
            }
            else if (direction == LineDirection.Vertical)
            {
                if (bottomLine.State == LineState.Filled) return false;
                bottomLine.State = LineState.Filled;
            }
            return true;
        }
    }
}
