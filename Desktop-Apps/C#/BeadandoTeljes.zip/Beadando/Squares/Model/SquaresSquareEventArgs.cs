﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Squares.Model
{
    public class SquaresSquareEventArgs : EventArgs
    {
        private int x;
        private int y;
        private PlayerId player;
        public int X { get { return x; } }
        public int Y { get { return y; } }
        public PlayerId Player { get { return player; } }

        public SquaresSquareEventArgs(int x, int y, PlayerId player)
        {
            this.x = x;
            this.y = y;
            this.player = player;
        }
    }
}
