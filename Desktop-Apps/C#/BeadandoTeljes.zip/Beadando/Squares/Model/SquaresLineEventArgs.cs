﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Squares.Model
{
    public class SquaresLineEventArgs : EventArgs
    {
        private int x;
        private int y;
        private LineDirection direction;

        public int X { get { return x; } }
        public int Y { get { return y; } }
        public LineDirection Direction { get { return direction; } }

        public SquaresLineEventArgs(int x, int y, LineDirection direction)
        {
            this.x = x;
            this.y = y;
            this.direction = direction;
        }
    }
}
