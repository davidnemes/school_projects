﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Squares.Model
{
    public class SquaresGameEventArgs : EventArgs
    {
        private bool isGameOver;
        private PlayerId player;
        private int additionalData;

        public bool IsGameOver { get {  return isGameOver; } }
        public PlayerId Player {  get { return player; } }
        public int AdditionalData {  get { return additionalData; } }
        public SquaresGameEventArgs(bool isGameOver, PlayerId player, int additionalData = -1)
        {
            this.isGameOver = isGameOver;
            this.player = player;
            this.additionalData = additionalData;
        }

    }
}
