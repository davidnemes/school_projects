﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Squares.Model
{
    public enum LineState { Empty, Filled }
    public enum LineDirection { Horizontal, Vertical }
    public class SquaresLine
    {
        private LineState state;
        private LineDirection direction;
        private SquaresPoint point;

        public LineState State
        {
            get { return state; }
            set { state = value; }
        }
        public SquaresPoint Point { get { return point; } }
        public LineDirection Direction { get { return direction; } }

        public SquaresLine(SquaresPoint point, LineDirection direction)
        {
            state = LineState.Empty;
            this.point = point;
            this.direction = direction;
        }
    }
}
