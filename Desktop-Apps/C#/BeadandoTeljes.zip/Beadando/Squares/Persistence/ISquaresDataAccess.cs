﻿using Squares.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Squares.Persistence
{
    public interface ISquaresDataAccess
    {
        public Task<SquaresTable> LoadAsync(String path);
        public Task<SquaresTable> LoadAsync(Stream stream);
        public Task SaveAsync(String path, SquaresTable table);
        public Task SaveAsync(Stream path, SquaresTable table);
    }
}
