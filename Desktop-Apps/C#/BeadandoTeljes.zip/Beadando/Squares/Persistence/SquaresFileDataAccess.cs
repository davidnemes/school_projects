﻿using Squares.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Drawing;

namespace Squares.Persistence
{
    public class SquaresFileDataAccess : ISquaresDataAccess
    {
        public SquaresFileDataAccess() { }

        public async Task<SquaresTable> LoadAsync(string path)
        {
            return await LoadAsync(File.OpenRead(path));

        }

        public async Task<SquaresTable> LoadAsync(Stream stream)
        {
            try
            {
                using (StreamReader reader = new StreamReader(stream))
                {
                    string line = await reader.ReadLineAsync() ?? string.Empty;
                    string[] meta = line.Split(' ');
                    int tableSize = int.Parse(meta[0]);
                    string whoseTurn = meta[1];

                    SquaresTable table = new SquaresTable(tableSize);

                    table.AlterTable("loadedTableSize", tableSize, -1);


                    for (int i = 0; i < tableSize; i++)
                    {

                        line = await reader.ReadLineAsync() ?? String.Empty;
                        string[] topLine = line.Split('O').Where(x => x != "").ToArray();
                        if (topLine.Length != tableSize - 1) throw new Exception();

                        for (int j = 0; j < topLine.Length; j++)
                        {
                            if (topLine[j] == "-") table.AlterTable("fillRightLine", j, i);
                        }

                        if (i < tableSize - 1)
                        {
                            string? bottomLine = await reader.ReadLineAsync();
                            if (bottomLine == null || bottomLine.Length != tableSize + (tableSize - 1)) throw new Exception();
                            for (int j = 0; j < tableSize; j++)
                            {
                                int J = 2 * j;
                                if (bottomLine[J] == '|') table.AlterTable("fillBottomLine", j, i);
                                if (J + 1 < bottomLine.Length)
                                {
                                    if (bottomLine[J + 1] == 'R') table.AlterTable("fillSquareRed", j, i);
                                    if (bottomLine[J + 1] == 'B') table.AlterTable("fillSquareBlue", j, i);
                                }
                            }
                        }
                    }

                    table.AlterTable("playerTurns", -1, -1, whoseTurn == "B" ? PlayerId.Blue : PlayerId.Red);

                    return table;
                }
            }
            catch
            {
                throw new SquaresDataException();
            }
        }

        public async Task SaveAsync(string path, SquaresTable table)
        {
            await SaveAsync(File.OpenWrite(path), table);
        }

        public async Task SaveAsync(Stream stream, SquaresTable table)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(stream))
                {
                    int tableSize = table.Size;
                    SquaresPoint[,] points;
                    PlayerId[,] squaresState;
                    (points, squaresState) = table.DumpTable();

                    writer.Write($"{table.Size}"); // kiírjuk a méreteket
                    await writer.WriteLineAsync(" " + (table.CurrentPlayer == PlayerId.Blue ? "B" : "R"));

                    for (int j = 0; j < tableSize; j++)
                    {
                        StringBuilder firstLine = new StringBuilder();
                        StringBuilder secondLine = new StringBuilder();
                        for (int i = 0; i < tableSize; i++)
                        {
                            firstLine.Append("O");
                            if (i < tableSize - 1)
                            {
                                if (points[i, j].RightLine.State == LineState.Filled) firstLine.Append("-");
                                else firstLine.Append(" ");
                            }

                            if (j < tableSize - 1)
                            {
                                if (points[i, j].BottomLine.State == LineState.Filled) secondLine.Append("|");
                                else secondLine.Append(" ");


                            }
                            if (i < tableSize - 1 && j < tableSize - 1)
                            {
                                secondLine.Append(squaresState[i, j] == 0 ? " " : squaresState[i, j] == PlayerId.Blue ? "B" : "R");
                            }
                        }
                        await writer.WriteLineAsync(firstLine.ToString());
                        if (secondLine.ToString().Length > 0) await writer.WriteLineAsync(secondLine.ToString());
                    }
                }
            }
            catch
            {
                throw new SquaresDataException();
            }
        }
    }
}
