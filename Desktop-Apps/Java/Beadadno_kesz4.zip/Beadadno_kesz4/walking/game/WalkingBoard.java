package walking.game;

import walking.game.util.Direction;

public class WalkingBoard {

    // Fields
    private int[][] tiles;
    private int x;
    private int y;
    public static final int BASE_TILE_SCORE = 3;

    // Constructors
    public WalkingBoard(int size) {
        this.tiles = new int[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                tiles[i][j] = BASE_TILE_SCORE;
            }   
        }
    }
    public WalkingBoard(int[][] tiles) {
        this.tiles = new int[tiles.length][];
        for (int i = 0; i < tiles.length; i++) {
            this.tiles[i] = new int[tiles[i].length];
            for (int j = 0; j < tiles[i].length; j++) {
                this.tiles[i][j] = tiles[i][j] > BASE_TILE_SCORE ? tiles[i][j] : BASE_TILE_SCORE ;
            }   
        }
    }

    // Methods
    public int[] getPosition() {
        return new int[]{ this.x, this.y };
    }
    public boolean isValidPosition(int x, int y) {
        return x >= 0 && x < this.tiles.length && y >= 0 && y < this.tiles[x].length;
    }
    public int getTile(int x, int y) throws IllegalArgumentException {
        if (this.isValidPosition(x, y)) {
            return tiles[x][y];
        } else {
            throw new IllegalArgumentException("Invalid position!");
        }
    }
    public int[][] getTiles() {

        int[][] ret = new int[tiles.length][];
        for (int i = 0; i < tiles.length; i++) {
            ret[i] = new int[tiles[i].length];
            for (int j = 0; j < tiles[i].length; j++) {
                ret[i][j] = tiles[i][j];
            }
        }
        return ret;
    }
    public static int getXStep(Direction direction) {
        if (direction == Direction.LEFT) return -1;
        else if (direction == Direction.RIGHT) return 1;
        else return 0;
    }
    public static int getYStep(Direction direction) {
        if (direction == Direction.UP) return -1;
        else if (direction == Direction.DOWN) return 1;
        else return 0;
    }
    public int moveAndSet(Direction direction, int newValue) {
        int newX = getXStep(direction) + x;
        int newY = getYStep(direction) + y;
        if (!isValidPosition(newX, newY)) {
            return 0;
        }

        int ret = getTile(newX, newY);
        x = newX; y = newY;
        tiles[x][y] = newValue;
        return ret; 
    }

}