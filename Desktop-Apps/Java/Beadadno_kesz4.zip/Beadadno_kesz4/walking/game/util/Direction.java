package walking.game.util;

public enum Direction {
    UP, RIGHT, DOWN, LEFT;
}