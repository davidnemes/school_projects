package walking.game;

import walking.game.WalkingBoard;
import walking.game.util.Direction;

import static check.CheckThat.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.*;
import org.junit.jupiter.api.extension.*;
import org.junit.jupiter.params.*;
import org.junit.jupiter.params.provider.*;
import check.*;

public class WalkingBoardTest {
    @ParameterizedTest(name = "size = {0} : ")
    @CsvSource(textBlock = """
        1
        5
        10
    """)
    @DisableIfHasBadStructure
    public void testSimpleInit(int size) {
        WalkingBoard wb = new WalkingBoard(size);

        assertEquals(size, wb.getTiles().length);
        assertEquals(size, wb.getTiles()[0].length);

        assertEquals(WalkingBoard.BASE_TILE_SCORE, wb.getTile(0, 0));
        assertEquals(WalkingBoard.BASE_TILE_SCORE, wb.getTile(0, size-1));
        assertEquals(WalkingBoard.BASE_TILE_SCORE, wb.getTile(size-1, 0));
        assertEquals(WalkingBoard.BASE_TILE_SCORE, wb.getTile(size-1, size-1));
    }

    @ParameterizedTest(name = "Testcase : ")
    @CsvSource(textBlock = """
        1, 1, 4
        2, 2, 7
        0, 0, 3
        3, 0, 3
    """)
    @DisableIfHasBadStructure
    public void testCustomInit(int x, int y, int expected) {
        // Building custom board
        int[][] customBoard = new int[][]{
            {1,2,3},
            {3,4,5},
            {5,6,7},
            {0, 0},
        };
        WalkingBoard wb = new WalkingBoard(customBoard);

        // Testing deep copies
        int[][] board = wb.getTiles();
        customBoard[x][y] = 1001;
        board[x][y] = 1001;

        // Testing BASE_TILE_SCORE init, if smaller value, then overwrites
        assertEquals(WalkingBoard.BASE_TILE_SCORE, wb.getTile(3, 1));
        
        // Test
        assertEquals(expected, wb.getTile(x, y));
    }

    @Test
    public void testMoves() {
        //Building custom board
        int[][] customBoard = new int[][]{
            {1,3,5,0},
            {2,4,6,0},
            {3,5,7}
        };
        WalkingBoard wb = new WalkingBoard(customBoard);

        // Testing moves
        assertEquals(3, wb.moveAndSet(Direction.DOWN, 4));
        assertEquals(0, wb.getPosition()[0]);
        
        assertEquals(1, wb.getPosition()[1]);
        assertEquals(4, wb.getTile(0, 1));

        assertEquals(4, wb.moveAndSet(Direction.RIGHT, 4));
        assertEquals(5, wb.moveAndSet(Direction.RIGHT, 5));
        assertEquals(7, wb.moveAndSet(Direction.DOWN, 7));
        
        assertEquals(0, wb.moveAndSet(Direction.DOWN, 3));
        assertEquals(2, wb.getPosition()[0]);
        assertEquals(2, wb.getPosition()[1]);
        
        assertEquals(6, wb.moveAndSet(Direction.LEFT, 3));
        assertEquals(3, wb.moveAndSet(Direction.DOWN, 4));
        assertEquals(0, wb.moveAndSet(Direction.DOWN, 4));
        assertEquals(1, wb.getPosition()[0]);
        assertEquals(3, wb.getPosition()[1]);
    }


}