package walking.game.player;

import walking.game.util.Direction;

public class Player {
    // Fields
    private int score;
    public int getScore() {
        return score;
    }
    protected Direction direction = Direction.UP;
    public Direction getDirection() {
        return direction;
    }

    // Contructors
    public Player() {

    }

    // Methods
    public void addToScore(int score) {
        this.score += score;
    }
    public void turn() {
        this.direction = Direction.values()[(direction.ordinal()+1) % Direction.values().length];
    }

}