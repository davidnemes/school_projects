package walking.game.player;

import walking.game.util.Direction;

public class MadlyRotatingBuccaneer extends Player {
    private int turnCount = 0;
    public void turn() {
        this.direction = Direction.values()[(direction.ordinal()+this.turnCount) % Direction.values().length];
        turnCount++;
    }
    public MadlyRotatingBuccaneer() {
        super();
    }
}