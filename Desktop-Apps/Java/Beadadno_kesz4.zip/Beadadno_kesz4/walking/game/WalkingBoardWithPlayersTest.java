package walking.game;

import walking.game.util.Direction;

import static check.CheckThat.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.condition.*;
import org.junit.jupiter.api.extension.*;
import org.junit.jupiter.params.*;
import org.junit.jupiter.params.provider.*;
import check.*;

public class WalkingBoardWithPlayersTest {
    @Test
    public void walk1() {
        // Building board
        int[][] customBoard = new int[][]{
            {3,6,3},
            {4,3,4},
            {3,6,3},
        };
        WalkingBoardWithPlayers wb = new WalkingBoardWithPlayers(customBoard, 3);

        // Test 1
        // M: 7, p1: 6, p2: 3
        int[] expectedScores1 = new int[]{ 7, 10, 6 };
        int[][] expectedBoard1 = new int[][]{
            {3,6,10},
            {2,3,9},
            {3,6,7},
        };
        int[] scoresTest1 = wb.walk(2, 1, 1, 2, 1, 2, 2);
        int[][] boardTest1 = wb.getTiles();
        try {
            for (int i = 0; i < expectedScores1.length; i++) {
                assertEquals(expectedScores1[i], scoresTest1[i]);
            }
            for (int i = 0; i < expectedBoard1.length; i++) {
                for (int j = 0; j < expectedBoard1[i].length; j++) {
                    assertEquals(expectedBoard1[i][j], boardTest1[i][j]);
                }
            }

        } catch (Exception e) {
            fail();
        }

        // Test 2
        // M: 22, p1: 13, p2: 13
        // M: left, p1: up, p2: up
        int[] expectedScores2 = new int[]{ 7, 19, 6 };
        int[][] expectedBoard2 = new int[][]{
            {8,7,10},
            {2,3,9},
            {3,6,7},
        };
        int[] scoresTest2 = wb.walk(3, 1, 2, 1, 2, 2);
        int[][] boardTest2 = wb.getTiles();

        try {
            for (int i = 0; i < expectedScores2.length; i++) {
                assertEquals(expectedScores2[i], scoresTest2[i]);
            }
            for (int i = 0; i < expectedBoard2.length; i++) {
                for (int j = 0; j < expectedBoard2[i].length; j++) {
                    assertEquals(expectedBoard2[i][j], boardTest2[i][j]);
                }
            }
        } catch (Exception e) {
            fail();
        }
    }

    @Test
    public void walk2() {
        // Building board
        int[][] customBoard = new int[][]{
            {5,6,3,4},
            {4,7,4,5},
            {5,6,3,4},
            {4,7,4,5},
        };
        WalkingBoardWithPlayers wb = new WalkingBoardWithPlayers(customBoard, 2);

        // Test
        // M: 27, p1: 22
        // M: left, p1: right
        int[] expectedScores1 = new int[]{ 18, 10 };
        int[][] expectedBoard1 = new int[][]{
            {6,7,8,4},
            {5,7,4,5},
            {4,6,3,4},
            {2,7,4,5},
        };
        wb.walk(0); // for the MadlyRotatingBuccaneer to start rotating (this way it will be his second round)
        int[] scoresTest1 = wb.walk(2, 2, 3, 1, 1, 2);
        int[][] boardTest1 = wb.getTiles();
        try {
            for (int i = 0; i < expectedScores1.length; i++) {
                assertEquals(expectedScores1[i], scoresTest1[i]);
            }
            for (int i = 0; i < expectedBoard1.length; i++) {
                for (int j = 0; j < expectedBoard1[i].length; j++) {
                    assertEquals(expectedBoard1[i][j], boardTest1[i][j]);
                }
            }
        } catch (Exception e) {
            fail();
        }
    }
}