package walking.game;

import walking.game.player.Player;
import walking.game.player.MadlyRotatingBuccaneer;

public class WalkingBoardWithPlayers extends WalkingBoard {
    // Fields
    private Player[] players;
    private int round;
    public static final int SCORE_EACH_STEP = 13;
    
    // Constructors
    public WalkingBoardWithPlayers(int[][] board, int playerCount) throws IllegalArgumentException {
        super(board);
        this.initPlayers(playerCount);
    }
    public WalkingBoardWithPlayers(int size, int playerCount) throws IllegalArgumentException {
        super(size);
        this.initPlayers(playerCount);
    }

    // Methods
    private void initPlayers(int playerCount) throws IllegalArgumentException {
        if (playerCount < 2) throw new IllegalArgumentException("Player count is less than 2!");

        this.players = new Player[playerCount];
        this.players[0] = new MadlyRotatingBuccaneer();
        for (int i = 1; i < this.players.length; i++) {
            this.players[i] = new Player();
        }
    }
    public int[] walk(int... stepCounts) {
        int currentPlayer = 0;
        int allSteps = 0;
        for (int stepCount : stepCounts) {
            Player player = this.players[currentPlayer];
            player.turn();
            
            for (int i = 0; i < stepCount; i++) {
                int plusScore = this.moveAndSet(player.getDirection(), allSteps);
                player.addToScore(plusScore);
                if (allSteps < this.SCORE_EACH_STEP) allSteps++;
            }
            currentPlayer = (currentPlayer+1) % this.players.length;
        }

        int[] scores = new int[this.players.length];
        for (int i = 0; i < this.players.length; i++) scores[i] = this.players[i].getScore();
        return scores;
    }


}