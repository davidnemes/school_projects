#pragma once

// Spiral Matrix function definitions 

struct M {
    int dimension;
    int ** matrix;
    // u - up, d - down, l - left, r - right
    char startingDir;
    // 0 is cw, 1 is ccw
    int spinDir;
};

typedef struct M matrix_t;

void print_menu();

void print_user_guide();

matrix_t * generate_matrix();

void save_matrix(matrix_t * _matrix);

matrix_t * load_matrix();

void print_matrix(matrix_t * _matrix);

void destroy_matrix(matrix_t * _matrix);
void destroy_matrix_inner(int ** matrix, int n);

int ** allocate_matrix(int n);

int allowed_starting_direction(char startingDir);
