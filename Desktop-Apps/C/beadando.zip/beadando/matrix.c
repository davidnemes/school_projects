#include <stdio.h>
#include <stdlib.h>
#include "matrix.h"

#define ACTION_SIZE 20

void print_menu();
void print_user_guide();
matrix_t * generate_matrix();
void save_matrix(matrix_t * _matrix);
matrix_t * load_matrix();
void print_matrix(matrix_t * _matrix);
void destroy_matrix(matrix_t * _matrix);

int main() {

    char action[ACTION_SIZE];
    char input[ACTION_SIZE];
    matrix_t * currentMatrix = NULL;

    print_menu();
    while (printf(">> "), fgets(input, ACTION_SIZE, stdin)) {

        if ( 1 != sscanf(input, "%s", action)) continue;
        switch(action[0]) {
            case 48:
                print_user_guide();
                break;
            case 49:
                destroy_matrix(currentMatrix);
                currentMatrix = generate_matrix();
                break;
            case 50:
                save_matrix(currentMatrix);
                break;
            case 51:
                destroy_matrix(currentMatrix);
                currentMatrix = load_matrix();
                break;
            case 52:
                print_matrix(currentMatrix);
                break;
            case 53:
                destroy_matrix(currentMatrix);
                printf("Exiting...");
                exit(0);
                break;
            default:
                printf("Unknown command!\n");
                break;
        }
    }

    return 0;
}


