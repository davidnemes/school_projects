#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "matrix.h"

#define INPUT_SIZE 10
#define FILENAME_SIZE 40
#define BUFFER_SIZE 120

void print_menu() {
    printf("\n| --------------------- |\n");
    printf("| Spiral Matrix Program |\n");
    printf("| --------------------- |\n");
    printf("Commands:\n");
    printf("0 - User Guide\n");
    printf("1 - Generate a matrix\n");
    printf("2 - Save a matrix\n");
    printf("3 - Load a matrix\n");
    printf("4 - Print current matrix\n");
    printf("5 - Exit\n");
}

void print_user_guide() {
    printf("This is a Spiral Matrix generator and handler program.\n");
    printf(" - You can generate a matrix by giving the dimension, the starting direction,\n");
    printf("    and the spin direction. Matrix will be in memory. (1)\n");
    printf(" - You can save a matrix to a file, which is done automatically by the program. (2)\n");
    printf("    Naming: spiral_DIM_START_SPIN.txt, where DIM is a number (1-20), START is the starting\n");
    printf("    direction (u/d/l/r), and SPIN is the spinning direction (cw/ccw).\n");
    printf(" - You can load a matrix from a file with the naming: spiral_DIM_STARTDIR_SPINDIR.txt (3)\n");
    printf("    Only files with correct naming can be loaded.\n");
    printf("    Matrix will be loaded to the memory. Only one matrix can be in memory, previous matrix is\n");
    printf("    lost if there was any.\n");
    printf(" - Print the current matrix which is in the memory. (4)\n");
    printf(" - Exit from the program. (5)\n");
}

matrix_t * generate_matrix() {
    printf(" -- Generate a Matrix\n");
    char input[INPUT_SIZE];

    // Read matrix dimension (NxN)
    printf("Matrix Dimension (1-20): ");
    fgets(input, INPUT_SIZE, stdin);
    int n = atoi(input);
    if (n < 1 || n > 20) {
        printf(" ** Wrong Dimension!\n");
        return 0;
    }

    // Read starting direction
    printf("Starting Direction (u/d/l/r): ");
    fgets(input, INPUT_SIZE, stdin);
    char startingDir = input[0];
    if (!allowed_starting_direction(startingDir)) {
        printf(" ** Wrong Starting Direction!\n");
        return 0;
    }

    // Read Spin Direction
    printf("Spin Direction (cw/ccw): ");
    fgets(input, INPUT_SIZE, stdin);
    int spinDir = -1;
    if (input[0] == 'c' && input[1] == 'w') spinDir = 0;
    if (input[0] == 'c' && input[1] == 'c' && input[2] == 'w') spinDir = 1;
    if (spinDir == -1) {
        printf(" ** Wrong Spin Direction!\n");
        return 0;

    }

    // Allocating Matrix
    int ** matrix = allocate_matrix(n);
    if (!matrix) return 0;

    // Fill the Matrix
    int safeInMatrix = 1;
    // a is the row, b is the column
    int a = n/2, b = n/2;
    char directions[] = {'u', 'r', 'd', 'l'};
    //                    0    1    2    3
    int direction;
    for (int i = 0; i < 4; ++i) if (directions[i] == startingDir) direction = i;
    // fixing starting point
    if (n%2 == 0) {
        if (direction == 2 || (direction == 3 && spinDir) || (direction == 1 && !spinDir)) a--;
        if (direction == 1 || (direction == 2 && spinDir) || (direction == 0 && !spinDir)) b--;
    }

    int counter = 1;
    matrix[a][b] = counter;

    while (safeInMatrix) {
        if (direction == 0) a--;
        else if (direction == 1) b++;
        else if (direction == 2) a++;
        else if (direction == 3) b--;
        // if (counter < 10) printf("row is = %d, column is = %d\n", a, b);

        if (a < 0 || b < 0 || a >= n || b >= n) {
            safeInMatrix = 0;
            continue;
        }
        matrix[a][b] = ++counter;
        
        // check if side is 0 (if direction has to be changed)
        int sideDirection = direction;
        if (!spinDir) sideDirection++;
        else sideDirection--;
        if (sideDirection > 3) sideDirection -= 4;
        if (sideDirection < 0) sideDirection += 4;

        int sideA = a, sideB = b;
        if (sideDirection == 0) sideA--;
        else if (sideDirection == 1) sideB++;
        else if (sideDirection == 2) sideA++;
        else if (sideDirection == 3) sideB--;

        if (!matrix[sideA][sideB]) { // this never goes out of the matrix
            direction = sideDirection;
        }
    }

    // Creating Matrix struct
    matrix_t * _matrix = (matrix_t*) malloc(sizeof(matrix_t));
    if (!_matrix) {
        destroy_matrix_inner(matrix, n);
        printf (" ** Memory alloc failed!\n");
        return 0;
    }
    _matrix->dimension = n;
    _matrix->matrix = matrix;
    _matrix->startingDir = startingDir;
    _matrix->spinDir = spinDir;

    printf("Done!\n");

    return _matrix;
}

void save_matrix(matrix_t * _matrix) {
    printf(" -- Save Matrix to a file\n");
    if (!_matrix) {
        printf("Empty Matrix!\n");
        return;
    }

    // Creating filename
    char spinDir[4] = { 'c' };
    if (_matrix->spinDir == 0) {
        spinDir[1] = 'w';
        spinDir[2] = '\0';
    } else {
        spinDir[1] = 'c';
        spinDir[2] = 'w';
        spinDir[3] = '\0';
    }
    char filename[FILENAME_SIZE];
    snprintf(filename, sizeof filename, "spiral_%d_%c_%s.txt", _matrix->dimension, _matrix->startingDir, spinDir);

    // Writing to file
    int ** matrix = _matrix->matrix;
    int n = _matrix->dimension;
    FILE * file = fopen(filename, "w");
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            fprintf(file, "%3d ", matrix[i][j]);
        }
        fprintf(file, "\n");
    }
    fclose(file);

    printf("Done!\n");
}

matrix_t * load_matrix() {
    printf(" -- Load Matrix from a file (spiral_DIM_START_SPIN.txt)\n");
    char input[FILENAME_SIZE];

    // Read filename
    printf("File name: ");
    fgets(input, FILENAME_SIZE, stdin);
    // FILE * file = fopen("spiral_6_d_ccw.txt", "r");
    char filename[FILENAME_SIZE];
    sscanf(input, "%s", filename);
    
    // Find dimension, starting direction and spin direction from filename
    char filenameDelimiters[] = "_.";
    strtok(input, filenameDelimiters);
    char * dimString = strtok(NULL, filenameDelimiters);
    if (!dimString) {
        printf(" ** Wrong filename\n");
        return 0;
    }
    int dim = atoi(dimString);
    if (!dim) {
        printf(" ** Dimension cannot be found in filename\n");
        return 0;
    }
    char startingDir = (strtok(NULL, filenameDelimiters))[0];
    if (!allowed_starting_direction(startingDir)) {
        printf(" ** Starting direction cannot be found in filename\n");
        return 0;
    }
    int spinDir = -1;
    char * spinDirStr = strtok(NULL, filenameDelimiters);
    if (spinDirStr[0] == 'c' && spinDirStr[1] == 'w') spinDir = 0;
    else if (spinDirStr[0] == 'c' && spinDirStr[1] == 'c' && spinDirStr[2] == 'w') spinDir = 1;
    if (spinDir == -1) {
        printf(" ** Spin direction cannot be found in filename\n");
        return 0;
    }

    // printf("data is: dim %d, startingDir %c, spinDir %d\n", dim, startingDir, spinDir);
    // return 0;

    //// PROCESSING FILE ////
    FILE * file = fopen(filename, "r");

    if (!file) {
        printf(" ** File not found!\n");
        return 0;
    }
    char buf[BUFFER_SIZE];
    char * num;
    char delimiters[] = " ";

    // Create matrix
    int ** matrix = allocate_matrix(dim);
    if (!matrix) {
        fclose(file);
        return 0;
    }
    for (int i = 0; i < dim; ++i) {
        fgets(buf, BUFFER_SIZE, file);
        num = strtok(buf, delimiters);

        for (int j = 0; j < dim; ++j) {
            matrix[i][j] = atoi(num);
            num = strtok(NULL, delimiters);
        }
    }
    fclose(file);
    // Create matrix struct
    matrix_t * _matrix = (matrix_t*) malloc(sizeof(matrix_t));
    if (!_matrix) {
        destroy_matrix_inner(matrix, dim);
        printf (" ** Memory alloc failed!\n");
        return 0;
    }
    _matrix->dimension = dim;
    _matrix->matrix = matrix;
    _matrix->startingDir = startingDir;
    _matrix->spinDir = spinDir;

    printf("Done!\n");
    return _matrix;
}

void print_matrix(matrix_t * _matrix) {
    printf(" -- Printing current matrix:\n");
    if (!_matrix) {
        printf("Empty Matrix!\n");
        return;
    }
    int ** matrix = _matrix->matrix;
    int n = _matrix->dimension;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            // if (matrix[i][j] < 10) printf(" ");
            printf("%3d ", matrix[i][j]);
        }
        printf("\n");
    }
}

/* 
 * HELPERS
 */

// Free Memory (etc. when exiting, or generating new matrix)
void destroy_matrix(matrix_t * _matrix) {
    if (!_matrix) return;
    destroy_matrix_inner(_matrix->matrix, _matrix->dimension);
    free(_matrix);
}

void destroy_matrix_inner(int ** matrix, int n) {
    if (!matrix) return;
    for (int i = 0; i < n; ++i) {
        if (matrix[i]) free(matrix[i]);
    }
    free(matrix);
}

int ** allocate_matrix(int n) {
    int ** matrix;
    matrix = (int**) malloc(sizeof(int*)*n);
    if (!matrix) {
        printf (" ** Memory alloc failed!\n");
        return 0;
    }
    for (int i = 0; i < n; ++i) {
        matrix[i] = (int*) calloc(n, sizeof(int));
        if (!matrix[i]) {
            for (int j = 0; j < i; ++j) free(matrix[j]);
            free(matrix);

            printf (" ** Memory alloc failed!\n");
            return 0;
        }
    }
    return matrix;
}

int allowed_starting_direction(char startingDir) {
    char allowedDirections[] = {'u', 'd', 'l', 'r'};
    int validDirection = 0;
    for (int i = 0; i < 4; ++i) if (allowedDirections[i] == startingDir) validDirection = 1;
    return validDirection;
}
